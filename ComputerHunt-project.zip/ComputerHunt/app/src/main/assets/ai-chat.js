// Offline AI helper. Works in the APK (window.AI) and falls back to a demo in a normal browser.
const AIChat = (() => {
  const pending = {};
  let counter = 0;

  const api = {
    onStatus: null,
    available() { return typeof window.AI !== 'undefined'; },
    status() { return this.available() ? window.AI.status() : 'ready'; },
    pickModel() { if (this.available()) window.AI.pickModel(); },
    sessionId() { return this.available() ? window.AI.sessionId() : 'browser'; },
    info() {
      if (!this.available()) return null;
      try { return JSON.parse(window.AI.info()); } catch (e) { return null; }
    },
    // Saves a text file into the phone's Downloads folder (browser: normal download)
    save(name, content) {
      if (this.available() && typeof window.AI.saveReport !== 'undefined') return window.AI.saveReport(name, content);
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([content], { type: 'text/plain' }));
      a.download = name; a.click();
      return 'ok:' + name;
    },
    resetModel() { if (this.available()) window.AI.resetModel(); },
    onVerify: null,
    verifyModel() {
      if (this.available()) window.AI.verifyModel();
      else setTimeout(() => { if (this.onVerify) this.onVerify({ error: 'only available inside the APK' }); }, 400);
    },
    setSysMode(m) { if (this.available()) window.AI.setSysMode(m); },
    restart() { if (this.available()) window.AI.restart(); else location.reload(); },

    // onToken(piece) streams; onEnglish(full); onPersian(text) arrives last; onError(msg)
    send(userText, onEnglish, onPersian, onToken, onError, opts) {
      if (!this.available()) {
        const demo = '<think>The user wrote something. I will answer briefly.</think>Hello! This is a demo reply (browser preview).';
        const parts = demo.match(/.{1,6}/g);
        let i = 0;
        const tick = () => {
          if (i < parts.length) { if (onToken) onToken(parts[i++]); setTimeout(tick, 60); }
          else { onEnglish(demo); onPersian('(پیش‌نمایش مرورگر)'); }
        };
        setTimeout(tick, 800);
        return;
      }
      const id = 'r' + (++counter);
      pending[id] = { onEnglish, onPersian, onToken, onError };
      const mt = (opts && opts.maxTokens) || 0;
      if (typeof window.AI.chat2 !== 'undefined') window.AI.chat2(id, userText, mt);
      else window.AI.chat(id, userText);
    }
  };

  window.onAiMessage = ({ id, lang, text }) => {
    const p = pending[id];
    if (!p) return;
    if (lang === 'token') { if (p.onToken) p.onToken(text); }
    else if (lang === 'en') p.onEnglish(text);
    else if (lang === 'fa') { p.onPersian(text); delete pending[id]; }
    else if (lang === 'error') { if (p.onError) p.onError(text); delete pending[id]; }
  };
  window.onAiVerify = r => { if (api.onVerify) api.onVerify(r); };
  window.onAiStatus = ({ status, detail }) => { if (api.onStatus) api.onStatus(status, detail); };
  return api;
})();
