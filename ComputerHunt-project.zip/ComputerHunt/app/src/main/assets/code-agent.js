// Coding agent: a designer model plans, a coder model works through tools (CodeTools), results are verified and fixed.
// Pure logic: the model is injected as llm(system, user, opt) -> Promise<{text, ms}>, so everything is testable without a phone.
const CodeAgent = (() => {
  'use strict';
  const CODER_TOOLS = ['list_files', 'read_file', 'code_map', 'search', 'edit_file', 'replace_lines', 'write_file', 'rename_symbol', 'check_js', 'html_check', 'html_outline', 'to_html', 'run_js', 'ui_test', 'diff_last', 'undo'];
  const MUTATING = new Set(['edit_file', 'write_file', 'replace_lines', 'rename_symbol', 'delete_file', 'undo', 'to_html']);
  const clip = (s, n) => { s = String(s == null ? '' : s); return s.length > n ? s.slice(0, n) + '...' : s; };
  const stripThink = s => String(s || '').replace(/<think>[\s\S]*?<\/think>/g, '').replace(/<think>[\s\S]*$/, '').trim();
  const STOP = { stop: true };

  // ---------- prompts (English: the models follow English instructions best) ----------
  function coderSystem(names) {
    return 'You are a careful coding agent working in a small project workspace (HTML, CSS, JavaScript; it runs in a phone browser).\n' +
      'You act by replying with EXACTLY ONE JSON object per turn and nothing else:\n{"tool":"<name>","args":{...}}\n\nTools:\n' + CodeTools.toolSpecText(names) +
      '\n- note(text: string): save a short working note that stays visible in later turns.\n- finish(summary: string): call when the task is done and verified.\n\n' +
      'Rules:\n1. Look before you edit: use code_map or search, then read_file on a small range.\n' +
      '2. Change existing files with edit_file (copy "find" exactly from read_file) or replace_lines. Use write_file only for new files.\n' +
      '3. After editing, verify with check_js or html_check, then run_js or ui_test.\n4. One tool call per reply. No prose, no code fences. Keep arguments short.\n' +
      '5. If a tool reports an error, fix the cause. Never repeat a failing call unchanged.\n\nExample reply: {"tool":"search","args":{"query":"addPoint"}}';
  }
  const DESIGNER_PLAN_SYS = 'You are the project designer for a small HTML/CSS/JavaScript project. Given a request and the workspace overview, write a SHORT plan as JSON: ' +
    '{"goal": string, "steps": [{"title": string, "files": [string], "detail": string}]}. Use 1 to 5 steps. Each detail is at most 2 sentences and names exact functions, ids or files when known. No code. Reply with JSON only.';
  const DESIGNER_DIAG_SYS = 'You analyze a failing verification report of a small HTML/CSS/JavaScript project. Reply with JSON only: {"cause": string, "fix": string}. Each field at most 30 words. Point to file:line from the report.';
  const PLAN_SCHEMA = { type: 'object', properties: { goal: { type: 'string' }, steps: { type: 'array', items: { type: 'object', properties: { title: { type: 'string' }, files: { type: 'array', items: { type: 'string' } }, detail: { type: 'string' } }, required: ['title', 'detail'] } } }, required: ['goal', 'steps'] };
  const DIAG_SCHEMA = { type: 'object', properties: { cause: { type: 'string' }, fix: { type: 'string' } }, required: ['cause', 'fix'] };
  function callSchema(names) {
    const base = CodeTools.toolCallSchema(names).anyOf;
    base.push({ type: 'object', properties: { tool: { const: 'note' }, args: { type: 'object', properties: { text: { type: 'string' } }, required: ['text'] } }, required: ['tool', 'args'] });
    base.push({ type: 'object', properties: { tool: { const: 'finish' }, args: { type: 'object', properties: { summary: { type: 'string' } }, required: ['summary'] } }, required: ['tool', 'args'] });
    return { anyOf: base };
  }

  // ---------- parsing model output ----------
  function allJson(text) {
    const s = String(text || ''), found = [];
    for (let i = 0; i < s.length; i++) {
      if (s[i] !== '{') continue;
      let depth = 0, inStr = false, esc = false, end = -1;
      for (let j = i; j < s.length; j++) {
        const c = s[j];
        if (inStr) { if (esc) esc = false; else if (c === '\\') esc = true; else if (c === '"') inStr = false; continue; }
        if (c === '"') inStr = true; else if (c === '{') depth++; else if (c === '}') { depth--; if (depth === 0) { end = j; break; } }
      }
      if (end < 0) continue;
      const raw = s.slice(i, end + 1); let o = null;
      try { o = JSON.parse(raw); } catch (e) { try { o = JSON.parse(raw.replace(/,\s*([}\]])/g, '$1').replace(/[\u201c\u201d]/g, '"')); } catch (e2) {} }
      if (o && typeof o === 'object') { found.push(o); i = end; }
    }
    return found;
  }
  function normalizeCall(o) {
    if (!o || typeof o !== 'object') return null;
    if (o.tool_call && typeof o.tool_call === 'object') return normalizeCall(o.tool_call);
    if (o.function && typeof o.function === 'object') return normalizeCall(o.function);
    const name = [o.tool, o.name, o.function, o.action, o.tool_name].find(x => typeof x === 'string' && x);
    if (!name) return null;
    let args = o.args !== undefined ? o.args : (o.arguments !== undefined ? o.arguments : (o.parameters !== undefined ? o.parameters : o.input));
    if (typeof args === 'string') { try { args = JSON.parse(args); } catch (e) { args = null; } }
    if (!args || typeof args !== 'object' || Array.isArray(args)) { args = {}; Object.keys(o).forEach(k => { if (!['tool', 'name', 'function', 'action', 'tool_name', 'args', 'arguments', 'parameters', 'input'].includes(k)) args[k] = o[k]; }); }
    return { tool: name.trim(), args };
  }
  // SEARCH/REPLACE blocks (a format small coder models know well) -> edit_file
  function parseSearchReplace(text) {
    const re = /<{5,9} SEARCH\r?\n([\s\S]*?)\r?\n={5,9}\r?\n([\s\S]*?)\r?\n?>{5,9} REPLACE/g; let m, path = '', edits = [];
    while ((m = re.exec(text))) {
      let p = '';
      const before = text.slice(0, m.index).split('\n').map(l => l.trim()).filter(l => l && !/^```/.test(l));
      if (before.length) p = before[before.length - 1].replace(/^(file|path)\s*:\s*/i, '').replace(/[`*]/g, '').trim();
      if (!path) path = p; else if (p && p !== path && !/^(=|<|>)/.test(p)) continue;
      edits.push({ find: m[1], replace: m[2] });
    }
    return edits.length && path ? { tool: 'edit_file', args: { path, edits } } : null;
  }
  function parseToolCall(raw, allowed) {
    const text = stripThink(raw); if (!text) return { ok: false, error: 'Empty reply.' };
    const objs = allJson(text);
    for (const o of objs) {
      const c = normalizeCall(o); if (!c) continue;
      if (!allowed.includes(c.tool)) return { ok: false, error: 'Unknown tool "' + c.tool + '". Allowed: ' + allowed.join(', ') + '.' };
      return { ok: true, call: c, via: 'json', multiple: objs.length > 1 };
    }
    const sr = parseSearchReplace(text); if (sr) return { ok: true, call: sr, via: 'search-replace' };
    return { ok: false, error: objs.length ? 'JSON found but no "tool" field. Reply like {"tool":"read_file","args":{"path":"game.js"}}.' : 'No JSON tool call found. Reply with exactly one JSON object like {"tool":"search","args":{"query":"x"}}.' };
  }
  function parsePlan(raw) {
    for (const o of allJson(stripThink(raw))) {
      if (!o || !Array.isArray(o.steps) || !o.steps.length) continue;
      const steps = o.steps.slice(0, 6).map(s => ({ title: clip(s && s.title || 'Step', 120), files: Array.isArray(s && s.files) ? s.files.slice(0, 6).map(String) : [], detail: clip(s && s.detail || '', 300) }));
      return { goal: clip(o.goal || '', 200), steps };
    }
    return null;
  }

  // ---------- prompt assembly with a character budget ----------
  const argHint = a => { a = a || {}; if (a.path) return a.path + (a.from ? ':' + a.from + (a.to ? '-' + a.to : '') : ''); if (a.query) return JSON.stringify(a.query); if (a.old) return a.old + '->' + a.new; return ''; };
  const oneLine = t => t.call.tool + ' ' + argHint(t.call.args) + ' -> ' + (t.result.ok ? 'ok' : 'ERROR') + ': ' + clip(String(t.result.text).split('\n')[0], 70);
  function buildUser(st, budget) {
    const head = ['TASK: ' + clip(st.task, 1500)];
    if (st.notes.length) head.push('NOTES:\n' + clip(st.notes.join('\n'), 700));
    if (st.hint) head.push('HINT: ' + st.hint);
    head.push('FILES: ' + clip(Object.keys(st.ws.files).sort().join(', '), 400));
    const tail = 'NEXT: reply with exactly one JSON tool call.';
    const T = st.turns, levels = [{ last: 1800, mid: 500, midN: 2, keep: 8 }, { last: 1200, mid: 250, midN: 1, keep: 6 }, { last: 700, mid: 0, midN: 0, keep: 4 }, { last: 300, mid: 0, midN: 0, keep: 2 }];
    for (const lv of levels) {
      const hist = [];
      T.forEach((t, i) => {
        const age = T.length - 1 - i;
        if (age >= lv.keep) return;
        const call = JSON.stringify(t.call).length > 300 ? t.call.tool + ' ' + argHint(t.call.args) : JSON.stringify(t.call);
        if (age === 0) hist.push('[' + t.n + '] ' + call + '\nRESULT: ' + clip(t.result.text, lv.last));
        else if (age <= lv.midN) hist.push('[' + t.n + '] ' + call + '\nRESULT: ' + clip(t.result.text, lv.mid));
        else hist.push('[' + t.n + '] ' + oneLine(t));
      });
      const dropped = Math.max(0, T.length - lv.keep);
      const out = head.join('\n') + '\n' + (hist.length ? 'HISTORY' + (dropped ? ' (' + dropped + ' older turns omitted)' : '') + ':\n' + hist.join('\n') + '\n' : '') + tail;
      if (out.length <= budget) return out;
      if (lv === levels[levels.length - 1]) {
        const last = T[T.length - 1], q = Math.floor(budget * 0.3);
        return 'TASK: ' + clip(st.task, q) + (st.hint ? '\nHINT: ' + clip(st.hint, 150) : '') + (last ? '\nHISTORY (older turns omitted):\n[' + last.n + '] ' + oneLine(last) + '\nRESULT: ' + clip(last.result.text, q) : '') + '\n' + tail;
      }
    }
  }

  // ---------- code completion (fill in the middle) for Qwen2.5-Coder ----------
  function buildFimPrompt(text, line, o) {
    o = o || {}; const L = String(text).split('\n'), at = Math.max(0, Math.min(L.length, Math.floor(line) || 0));
    const prefix = L.slice(0, at).join('\n'), suffix = '\n' + L.slice(at).join('\n');
    return { prompt: '<|fim_prefix|>' + prefix.slice(-(o.prefixChars || 1800)) + '<|fim_suffix|>' + suffix.slice(0, o.suffixChars || 700) + '<|fim_middle|>', prefix, suffix };
  }
  const cleanFim = s => String(s || '').replace(/<\|(?:endoftext|fim_[a-z]+|file_sep|repo_name|im_end|im_start)\|>/g, '').replace(/\r/g, '');
  function applyCompletion(ws, path, line, completion) {
    const p = CodeTools.normPath(path); if (!p || ws.files[p] == null) return { ok: false, text: 'File not found: ' + path };
    const f = buildFimPrompt(ws.files[p], line), c = cleanFim(completion);
    if (!c.trim()) return { ok: false, text: 'Empty completion.' };
    CodeTools.wsWrite(ws, p, f.prefix + c + f.suffix, 'complete');
    return { ok: true, text: 'Inserted ' + c.split('\n').length + ' line(s) after line ' + line + ' of ' + p + '.' };
  }
  async function complete(ws, path, line, llmRaw, o) {
    o = o || {}; const p = CodeTools.normPath(path); if (!p || ws.files[p] == null) return { ok: false, text: 'File not found: ' + path };
    const f = buildFimPrompt(ws.files[p], line, o), r = await llmRaw(f.prompt, { n: o.n || 96, temp: 0.2 });
    return { ok: true, completion: cleanFim(r.text), ms: r.ms, prompt: f.prompt };
  }

  // ---------- the agent loop ----------
  async function run(o) {
    const ws = o.ws, emit = ev => { try { if (o.onEvent) o.onEvent(ev); } catch (e) {} };
    const names = (o.tools || CODER_TOOLS).filter(n => CodeTools.TOOLS[n]), allowed = names.concat(['note', 'finish']), schema = callSchema(names);
    const budget = o.budgetChars || 6500, stats = { turns: 0, calls: 0, invalid: 0, llmMs: 0, swaps: 0, fixRounds: 0, edited: [] };
    const edited = new Set(), notes = []; let lastRole = null;
    const llm = async (role, system, user, opt) => {
      if (o.shouldStop && o.shouldStop()) throw STOP;
      const fn = role === 'designer' ? o.llmDesigner : o.llmCoder, t0 = Date.now(), r = await fn(system, user, opt), ms = r.ms || (Date.now() - t0);
      stats.llmMs += ms; if (lastRole && lastRole !== role && !o.sameModel) stats.swaps++; lastRole = role;
      emit({ type: 'llm', role, ms, chars: String(r.text || '').length }); return String(r.text || '');
    };
    const overview = async () => {
      const lines = Object.keys(ws.files).sort().map(p => p + ' (' + ws.files[p].split('\n').length + ' lines)'), maps = [];
      for (const p of Object.keys(ws.files).sort().filter(p => /\.(m?js|html?)$/i.test(p)).slice(0, 2)) { const r = await CodeTools.call(ws, 'code_map', { path: p }); if (r.ok) maps.push(clip(r.text, 700)); }
      return lines.join('\n') + (maps.length ? '\n\n' + maps.join('\n\n') : '');
    };
    async function runStep(task) {
      const st = { ws, task, notes, turns: [], hint: '' }, seen = new Map(); let invalidRun = 0, errRun = 0, hints = 0;
      for (let k = 0; k < (o.maxTurnsPerStep || 10); k++) {
        if (stats.turns >= (o.maxTotalTurns || 40)) return { status: 'limit', summary: 'Total turn limit reached.' };
        const txt = await llm('coder', coderSystem(names), buildUser(st, budget), { n: o.nTurn || 450, schema, temp: 0.2 });
        stats.turns++; const turn = stats.turns, p = parseToolCall(txt, allowed); st.hint = '';
        if (!p.ok) {
          stats.invalid++; invalidRun++; emit({ type: 'invalid', turn, reason: p.error, raw: clip(txt, 200) });
          st.turns.push({ n: turn, call: { tool: '(invalid)', args: {} }, result: { ok: false, text: 'Your reply was not a valid tool call: ' + p.error } });
          if (invalidRun >= 3) return { status: 'invalid', summary: 'The model kept producing invalid replies.' };
          continue;
        }
        invalidRun = 0; const call = p.call;
        if (p.multiple) st.hint = 'Only the first tool call of your reply was executed. Send one call per reply.';
        if (call.tool === 'finish') { emit({ type: 'finish', turn, summary: clip(call.args.summary, 400) }); return { status: 'done', summary: clip(call.args.summary || 'Done.', 400) }; }
        if (call.tool === 'note') { const t = clip(call.args.text, 200); if (t) notes.push(t); emit({ type: 'note', turn, text: t }); st.turns.push({ n: turn, call, result: { ok: true, text: 'Note saved.' } }); continue; }
        const sig = call.tool + JSON.stringify(call.args), cnt = (seen.get(sig) || 0) + 1; seen.set(sig, cnt);
        if (cnt >= 3) { hints++; if (hints >= 2) return { status: 'stuck', summary: 'The model repeated the same call without progress.' }; st.hint = 'You repeated the same call ' + cnt + ' times. Try a different approach, or call finish if the task is done.'; emit({ type: 'hint', turn, text: st.hint }); }
        emit({ type: 'call', turn, tool: call.tool, args: call.args, via: p.via });
        let res;
        if (o.beforeCall && MUTATING.has(call.tool) && (await o.beforeCall(call)) === false) res = { ok: false, text: 'The user rejected this change. Pick another approach, or call finish.' };
        else { if (o.shouldStop && o.shouldStop()) throw STOP; res = await CodeTools.call(ws, call.tool, call.args); stats.calls++; }
        if (res.ok && MUTATING.has(call.tool)) { (res.paths || (call.args.path ? [call.args.path] : [])).forEach(x => edited.add(CodeTools.normPath(x))); seen.clear(); }
        errRun = res.ok ? 0 : errRun + 1;
        emit({ type: 'result', turn, ok: res.ok, text: clip(res.text, 700) });
        st.turns.push({ n: turn, call, result: { ok: res.ok, text: res.text } });
        if (errRun >= 4) return { status: 'errors', summary: 'Four tool errors in a row.' };
      }
      return { status: 'limit', summary: 'Step turn limit reached.' };
    }
    async function verifyProject() {
      const lines = []; let ok = true;
      for (const p of [...edited].filter(p => /\.m?js$/i.test(p) && ws.files[p] != null)) { const r = await CodeTools.call(ws, 'check_js', { path: p }); if (r.errors) { ok = false; lines.push(r.text); } }
      const pages = o.entry && ws.files[o.entry] != null ? [o.entry] : Object.keys(ws.files).sort().filter(p => /\.html?$/i.test(p) && !/\.bundle\.html$/i.test(p)).slice(0, 1);
      for (const h of pages) {
        const r = await CodeTools.call(ws, 'html_check', { path: h }); if (r.errors) { ok = false; lines.push(r.text); }
        if (o.verifyRun !== false && typeof document !== 'undefined') { const rr = await CodeTools.call(ws, 'run_js', { path: h, seconds: 2 }); if (rr.errors) { ok = false; lines.push(rr.text); } }
      }
      return { ok, text: lines.length ? lines.join('\n') : (pages.length || edited.size ? 'All checks passed.' : 'Nothing to verify.') };
    }
    try {
      emit({ type: 'start', request: clip(o.request, 300) });
      let plan = { goal: clip(o.request, 200), steps: [{ title: clip(o.request, 120), files: [], detail: '' }] };
      if (o.useDesigner && o.llmDesigner) {
        try {
          const txt = await llm('designer', DESIGNER_PLAN_SYS, 'REQUEST: ' + clip(o.request, 1200) + '\nWORKSPACE:\n' + clip(await overview(), 1800), { n: o.nPlan || 320, schema: PLAN_SCHEMA, temp: 0.3 });
          const pl = parsePlan(txt); if (pl) plan = pl; else emit({ type: 'warn', text: 'The plan could not be parsed; using the request as one step.' });
        } catch (e) { if (e === STOP) throw e; emit({ type: 'warn', text: 'Designer failed: ' + clip(e && e.message || e, 160) }); }
      }
      emit({ type: 'plan', plan });
      const results = [];
      for (let i = 0; i < plan.steps.length; i++) {
        const s = plan.steps[i]; emit({ type: 'step', index: i + 1, total: plan.steps.length, title: s.title });
        const task = clip(o.request, 600) + (plan.steps.length > 1 || s.detail ? '\nCURRENT STEP ' + (i + 1) + '/' + plan.steps.length + ': ' + s.title + (s.files.length ? '\nFiles: ' + s.files.join(', ') : '') + (s.detail ? '\nDetail: ' + s.detail : '') : '');
        const r = await runStep(task); results.push(r); if (r.status !== 'done') break;
      }
      let ok = results.length > 0 && results.every(r => r.status === 'done'), verified = null;
      if (ok && o.verify !== false) {
        for (let round = 0; ; round++) {
          const v = await verifyProject(); emit({ type: 'verify', ok: v.ok, text: clip(v.text, 900) });
          if (v.ok || round >= (o.maxFixRounds == null ? 2 : o.maxFixRounds)) { verified = v; break; }
          stats.fixRounds++; let diag = '';
          if (o.useDesigner && o.llmDesigner) {
            try { const d = allJson(stripThink(await llm('designer', DESIGNER_DIAG_SYS, 'VERIFICATION REPORT:\n' + clip(v.text, 1500), { n: 160, schema: DIAG_SCHEMA, temp: 0.2 })))[0]; if (d) diag = clip((d.cause || '') + ' Fix: ' + (d.fix || ''), 300); } catch (e) { if (e === STOP) throw e; }
            if (diag) emit({ type: 'diagnosis', text: diag });
          }
          const r = await runStep('Fix the problems found by verification.\n' + clip(v.text, 1200) + (diag ? '\nDesigner diagnosis: ' + diag : '')); results.push(r);
          if (r.status !== 'done') { verified = v; break; }
        }
        ok = !!(verified && verified.ok);
      }
      stats.edited = [...edited].filter(p => ws.files[p] != null);
      const summary = results.map(r => r.summary).filter(Boolean).join(' ');
      const reason = ok ? 'done' : (results.some(r => r.status !== 'done') ? (results.find(r => r.status !== 'done').status) : 'verification-failed');
      emit({ type: 'done', ok, reason, summary: clip(summary, 600), stats });
      return { ok, reason, summary, stats, plan, verified, steps: results };
    } catch (e) {
      if (e === STOP) { stats.edited = [...edited].filter(p => ws.files[p] != null); emit({ type: 'stopped', stats }); return { ok: false, stopped: true, reason: 'stopped', stats }; }
      emit({ type: 'error', text: clip(e && e.message || e, 300) }); stats.edited = [...edited].filter(p => ws.files[p] != null);
      return { ok: false, reason: 'error', error: String(e && e.message || e), stats };
    }
  }

  return { CODER_TOOLS, MUTATING, coderSystem, DESIGNER_PLAN_SYS, DESIGNER_DIAG_SYS, PLAN_SCHEMA, DIAG_SCHEMA, callSchema, allJson, normalizeCall, parseToolCall, parseSearchReplace, parsePlan,
    buildUser, buildFimPrompt, cleanFim, applyCompletion, complete, run };
})();
