// Studio core: model catalog, capability rules, command building and the
// generate -> critique -> refine loop. No DOM in this file, so it can be tested in Node.
const StudioCore = (() => {
  'use strict';
  const HF = 'https://huggingface.co/';

  // ---------- capabilities, roles, runtimes ----------
  // Which native binary and leading subcommand each runtime uses. Old llama.cpp ships llama-cli / llama-completion / llama-mtmd-cli;
  // new llama.cpp ships one "llama" binary with subcommands (llama completion ..., llama <mtmd subcommand> ...).
  let toolPlan = { oneshot: { name: 'llama-cli', prefix: [] }, mtmd: { name: 'llama-mtmd-cli', prefix: [] } };
  function planTools(rt, sub) {
    const has = n => !!(rt && rt.tools && rt.tools[n] && rt.tools[n].exists), s = Object.assign({ completion: 'completion', mtmd: 'mtmd-cli' }, sub || {});
    const oneshot = has('llama-completion') ? { name: 'llama-completion', prefix: [] } : has('llama-cli') ? { name: 'llama-cli', prefix: [] } : has('llama') ? { name: 'llama', prefix: [s.completion] } : { name: 'llama-cli', prefix: [] };
    const mtmd = has('llama-mtmd-cli') ? { name: 'llama-mtmd-cli', prefix: [] } : has('llama') ? { name: 'llama', prefix: [s.mtmd] } : { name: 'llama-mtmd-cli', prefix: [] };
    toolPlan = { oneshot, mtmd }; return toolPlan;
  }
  const getToolPlan = () => toolPlan;
  const pickOneShot = rt => planTools(rt, null).oneshot.name;
  // Read subcommand names from the output of "llama help all" (lines like "  completion   ...").
  function parseSubcommands(text) { const out = [], re = /^[ \t]{1,}([a-z][a-z0-9-]*)(?:[ \t]|$)/gm; let m; while ((m = re.exec(String(text || '')))) if (!out.includes(m[1])) out.push(m[1]); return out; }
  function detectSub(text) {
    const names = parseSubcommands(text), r = {};
    const comp = names.find(n => n === 'completion') || names.find(n => /^complet/.test(n)); if (comp) r.completion = comp;
    const mm = names.find(n => n === 'mtmd-cli') || names.find(n => /mtmd/.test(n)); if (mm) r.mtmd = mm;
    return r;
  }

  const CAPS = { text: 'متن', plan: 'پرامپت‌نویسی و تصمیم', json: 'خروجی JSON', vision: 'درک تصویر', gen: 'ساخت تصویر', edit: 'ویرایش تصویر', think: 'تفکر', code: 'کدنویسی', fim: 'تکمیل کد (FIM)' };
  const ROLES = {
    supervisor: { title: 'سرپرست', need: ['text', 'plan'] },
    generator: { title: 'تولید تصویر', need: ['gen'] },
    critic: { title: 'نقدکننده', need: ['vision'] },
    editor: { title: 'ویرایشگر', need: ['edit'], optional: true }
  };
  // Which capabilities a runtime can physically provide, and which files it needs.
  const RUNTIMES = {
    llama: { tool: 'llama-cli', allowed: ['text', 'plan', 'json', 'think', 'code', 'fim'], files: ['main'] },
    mtmd: { tool: 'llama-mtmd-cli', allowed: ['text', 'plan', 'json', 'think', 'vision'], files: ['main', 'mmproj'] },
    sd: { tool: 'sd-cli', allowed: ['gen', 'edit'], files: ['main'] }
  };

  const q = (repo, file) => HF + repo + '/resolve/main/' + file;
  const CATALOG = [
    { id: 'qwen3vl-2b', name: 'Qwen3-VL 2B Instruct', runtime: 'mtmd', caps: ['text', 'plan', 'json', 'vision'], license: 'Apache-2.0',
      page: HF + 'Qwen/Qwen3-VL-2B-Instruct-GGUF', note: 'هم سرپرست، هم نقدکننده (پیشنهاد اصلی)',
      files: [
        { key: 'main', name: 'Qwen3VL-2B-Instruct-Q4_K_M.gguf', bytes: 1107409952, sha: '089d75c52f4b7ffc56ba998ffc50aae89fcafc755f9e7208aacca281dca6c2ae', url: q('Qwen/Qwen3-VL-2B-Instruct-GGUF', 'Qwen3VL-2B-Instruct-Q4_K_M.gguf') },
        { key: 'mmproj', name: 'mmproj-Qwen3VL-2B-Instruct-Q8_0.gguf', bytes: 445053216, sha: 'f9a68fabba69c3b81e153367b2c7521030b0fa8bb0de400c9599c8e6725f9c82', url: q('Qwen/Qwen3-VL-2B-Instruct-GGUF', 'mmproj-Qwen3VL-2B-Instruct-Q8_0.gguf') }] },
    { id: 'qwen3vl-4b', name: 'Qwen3-VL 4B Instruct', runtime: 'mtmd', caps: ['text', 'plan', 'json', 'vision'], license: 'Apache-2.0',
      page: HF + 'Qwen/Qwen3-VL-4B-Instruct-GGUF', note: 'باهوش‌تر ولی کندتر؛ حجم دقیق نامعلوم',
      files: [
        { key: 'main', name: 'Qwen3VL-4B-Instruct-Q4_K_M.gguf', bytes: null, url: q('Qwen/Qwen3-VL-4B-Instruct-GGUF', 'Qwen3VL-4B-Instruct-Q4_K_M.gguf') },
        { key: 'mmproj', name: 'mmproj-Qwen3VL-4B-Instruct-Q8_0.gguf', bytes: null, url: q('Qwen/Qwen3-VL-4B-Instruct-GGUF', 'mmproj-Qwen3VL-4B-Instruct-Q8_0.gguf') }] },
    { id: 'gemma4-e4b', name: 'Gemma 4 E4B (instruct)', runtime: 'mtmd', flexible: true, caps: ['text', 'plan', 'json', 'vision'],
      license: 'مجوز را در صفحه‌ی مدل ببین', page: HF + 'prithivMLmods/gemma-4-E4B-it-GGUF', extraArgs: '--top-k 64 --top-p 0.95',
      hint: { main: 'gemma-4-E4B-it-Q4_K_M.gguf', mmproj: 'gemma-4-E4B-it.mmproj-q8_0.gguf' },
      note: 'حدود ۵٫۳ گیگ + mmproj (۰٫۶ تا ۱ گیگ): روی گوشی ۸ گیگ خیلی تنگ و کند. هر دو فایل را با «افزودن فایل‌ها» انتخاب کن. لینک صفحه یک مخزن نمونه‌ی شخص ثالث است.',
      files: [] },
    { id: 'qwen3-1.7b', name: 'Qwen3 1.7B', runtime: 'llama', template: 'chatml', thinkBlock: true, caps: ['text', 'plan', 'json', 'think'], license: 'Apache-2.0',
      page: HF + 'Qwen/Qwen3-1.7B-GGUF', note: 'سرپرست متنی سبک (فقط Q8_0 رسمی)',
      files: [{ key: 'main', name: 'Qwen3-1.7B-Q8_0.gguf', bytes: 1834426016, url: q('Qwen/Qwen3-1.7B-GGUF', 'Qwen3-1.7B-Q8_0.gguf') }] },
    { id: 'qwen3-4b', name: 'Qwen3 4B', runtime: 'llama', template: 'chatml', thinkBlock: true, caps: ['text', 'plan', 'json', 'think'], license: 'Apache-2.0',
      page: HF + 'Qwen/Qwen3-4B-GGUF', note: 'سرپرست باهوش‌تر ولی کند',
      files: [{ key: 'main', name: 'Qwen3-4B-Q4_K_M.gguf', bytes: 2497280256, url: q('Qwen/Qwen3-4B-GGUF', 'Qwen3-4B-Q4_K_M.gguf') }] },
    { id: 'qwen35-4b', name: 'Qwen3.5 4B', runtime: 'llama', template: 'chatml', thinkBlock: true, caps: ['text', 'plan', 'json', 'think'], license: 'Apache-2.0',
      page: HF + 'unsloth/Qwen3.5-4B-GGUF', note: 'طراح و سرپرست استودیوی کد. معماری جدید است و به llama-cli ساخته‌شده از آخرین نسخه نیاز دارد؛ روی گوشی کند است',
      files: [{ key: 'main', name: 'Qwen3.5-4B-Q4_K_M.gguf', bytes: 2740937888, sha: '00fe7986ff5f6b463e62455821146049db6f9313603938a70800d1fb69ef11a4', url: q('unsloth/Qwen3.5-4B-GGUF', 'Qwen3.5-4B-Q4_K_M.gguf') }] },
    { id: 'qwen25coder-3b', name: 'Qwen2.5 Coder 3B Instruct', runtime: 'llama', template: 'chatml', caps: ['text', 'code', 'fim'], license: 'Qwen Research (غیرتجاری؛ پیش از انتشار بررسی شود)',
      page: HF + 'Qwen/Qwen2.5-Coder-3B-Instruct-GGUF', note: 'کدنویس استودیوی کد: تولید، تکمیل، بازنویسی و اصلاح کد',
      files: [{ key: 'main', name: 'qwen2.5-coder-3b-instruct-q4_k_m.gguf', bytes: 2104932800, sha: '724fb256bec1ff062b2f65e4569e871ad2e95ab2a3989723d1769c54294730b7', url: q('Qwen/Qwen2.5-Coder-3B-Instruct-GGUF', 'qwen2.5-coder-3b-instruct-q4_k_m.gguf') }] },
    { id: 'qwen25-1.5b', name: 'Qwen2.5 1.5B Instruct', runtime: 'llama', template: 'chatml', caps: ['text', 'plan'], license: 'Apache-2.0',
      page: HF + 'Qwen/Qwen2.5-1.5B-Instruct-GGUF', note: 'همان مدل چت فعلی؛ JSON را ضعیف می‌نویسد',
      files: [{ key: 'main', name: 'qwen2.5-1.5b-instruct-q4_k_m.gguf', bytes: 1117320736, sha: '6a1a2eb6d15622bf3c96857206351ba97e1af16c30d7a74ee38970e434e9407e', url: q('Qwen/Qwen2.5-1.5B-Instruct-GGUF', 'qwen2.5-1.5b-instruct-q4_k_m.gguf') }] },
    { id: 'sdturbo-q4', name: 'SD-Turbo (q4_0)', runtime: 'sd', family: 'turbo', caps: ['gen', 'edit'], license: 'Stability AI Community License',
      page: HF + 'samoudi/sd-turbo-gguf', note: 'تولید ۱ تا ۴ مرحله‌ای؛ ویرایش از نوع img2img (دقیق نیست)',
      files: [{ key: 'main', name: 'sd_turbo_q4_0.gguf', bytes: 1847909248, sha: 'd069ef2b2d3d5c2465662d706c242a1016db56163c109bd7e3008a94cdd00359', url: q('samoudi/sd-turbo-gguf', 'sd_turbo_q4_0.gguf') }] },
    { id: 'sdturbo-q8', name: 'SD-Turbo (q8_0)', runtime: 'sd', family: 'turbo', caps: ['gen', 'edit'], license: 'Stability AI Community License',
      page: HF + 'samoudi/sd-turbo-gguf', note: 'کمی بهتر، رم بیشتر (حدود ۶ گیگ پیشنهادی سازنده)',
      files: [{ key: 'main', name: 'sd_turbo_q8_0.gguf', bytes: 2149136352, sha: '604cfbd79e72706884027ea9e883c2daf9b243598b71daa19b15871f6d8dc15f', url: q('samoudi/sd-turbo-gguf', 'sd_turbo_q8_0.gguf') }] }
  ];

  // Image-model families: sensible defaults per family, so any compatible model can be accepted.
  const FAMILIES = {
    turbo: { title: 'Turbo (SD-Turbo / SDXL-Turbo)', steps: 2, cfg: 1.0, sampler: 'euler_a', size: 512, maxSize: 768, negative: false,
      presets: { fast: [256, 1], balanced: [512, 2], quality: [512, 4] }, note: '۱ تا ۴ مرحله، cfg=1، پرامپت منفی اثر ندارد' },
    lcm: { title: 'LCM (SD1.5 + LCM)', steps: 4, cfg: 1.5, sampler: 'lcm', size: 512, maxSize: 768, negative: true,
      presets: { fast: [384, 2], balanced: [512, 4], quality: [512, 6] }, note: '۲ تا ۸ مرحله، cfg حدود ۱ تا ۲' },
    sd15: { title: 'SD 1.5 معمولی', steps: 20, cfg: 7.0, sampler: 'euler_a', size: 512, maxSize: 768, negative: true,
      presets: { fast: [384, 12], balanced: [512, 20], quality: [640, 30] }, note: '۲۰ مرحله‌ی معمولی؛ روی CPU گوشی کند' },
    sdxl: { title: 'SDXL', steps: 25, cfg: 7.0, sampler: 'euler_a', size: 768, maxSize: 1024, negative: true,
      presets: { fast: [512, 15], balanced: [768, 25], quality: [1024, 35] }, note: 'سنگین؛ برای این گوشی توصیه نمی‌شود' }
  };
  const SAMPLERS = ['euler_a', 'euler', 'dpm++2m', 'lcm', 'heun', 'ddim_trailing'];
  const MODES = {
    loop: { title: 'حلقه‌ی خودکار', roles: ['supervisor', 'generator', 'critic'], desc: 'سرپرست پرامپت می‌نویسد، تصویر ساخته و نقد می‌شود و خودکار تکرار می‌شود.' },
    manual: { title: 'با تأیید من', roles: ['supervisor', 'generator', 'critic'], desc: 'مثل حلقه، ولی بعد از هر نقد تو تصمیم می‌گیری (قبول، ساخت دوباره، ویرایش، توقف) و می‌توانی پرامپت را اصلاح کنی.' },
    direct: { title: 'مستقیم', roles: ['generator'], desc: 'پرامپتِ خودت مستقیم به مدل تصویر می‌رود (انگلیسی بنویس)؛ چند تصویر با seedهای متفاوت. بدون سرپرست و نقد.' }
  };

  const DEFAULTS = {
    maxRounds: 3, acceptScore: 8, threads: 4, ctx: 4096, temp: 0.4, strength: 0.55, seed: 42, seedMode: 'inc', count: 2,
    gen: { size: null, steps: null, cfg: null, sampler: null, negative: '' },
    nPlan: 220, nCritic: 600, supThink: false, timeoutLlm: 900, timeoutSd: 1200,
    extra: { llama: '-no-cnv --no-display-prompt', mtmd: '', sd: '--vae-tiling' },
  sub: { completion: 'completion', mtmd: 'mtmd-cli' }
  };

  // Effective generation parameters = user override, else the model family's default.
  function genParams(model, S) {
    const famKey = FAMILIES[model.family] ? model.family : 'turbo', fam = FAMILIES[famKey], g = (S && S.gen) || {};
    const pick = k => (g[k] != null && g[k] !== '' ? g[k] : fam[k]);
    return { family: famKey, size: Math.min(Number(pick('size')), fam.maxSize), steps: Math.max(1, Math.round(Number(pick('steps')))),
      cfg: Number(pick('cfg')), sampler: String(pick('sampler')), negative: fam.negative ? String(g.negative || '') : '', negativeIgnored: !fam.negative && !!g.negative };
  }
  // seedMode: 'random' | 'fixed' | 'inc' (base seed + index)
  function seedFor(S, i) {
    if (S.seedMode === 'random') return Math.floor(Math.random() * 2147483647);
    if (S.seedMode === 'fixed') return Number(S.seed) || 0;
    return (Number(S.seed) || 0) + i;
  }

  // ---------- validation ----------
  function validateModelDef(m) {
    const errs = [], rt = RUNTIMES[m.runtime];
    if (!rt) return ['runtime نامعتبر'];
    (m.caps || []).forEach(c => {
      if (!CAPS[c]) errs.push('قابلیت ناشناخته: ' + c);
      else if (!rt.allowed.includes(c)) errs.push('runtime «' + m.runtime + '» نمی‌تواند «' + CAPS[c] + '» بدهد');
    });
    if (m.runtime === 'sd' && m.family && !FAMILIES[m.family]) errs.push('خانواده‌ی مدل تصویری نامعتبر: ' + m.family);
    return errs;
  }

  function fileStatus(m, listing) {
    const L = listing || [], rt = RUNTIMES[m.runtime], out = {};
    if (!rt) return out;
    rt.files.forEach(key => {
      const decl = m.flexible ? null : (m.files || []).find(x => x.key === key);
      let f = null;
      if (decl) f = L.find(x => x.name.toLowerCase() === decl.name.toLowerCase());
      else if (key === 'mmproj') f = L.find(x => /mmproj/i.test(x.name));
      else f = L.find(x => /\.(gguf|safetensors)$/i.test(x.name) && !/mmproj/i.test(x.name));
      out[key] = { key, name: f ? f.name : (decl ? decl.name : ((m.hint && m.hint[key]) || (key === 'mmproj' ? 'mmproj-*.gguf' : '*.gguf'))),
        have: !!f, bytes: f ? f.bytes : 0, expected: decl ? decl.bytes : null,
        ok: !!f && (!decl || !decl.bytes || decl.bytes === f.bytes) };
    });
    return out;
  }

  function eligibleNeed(m, need, listing) {
    const reasons = validateModelDef(m);
    const miss = need.filter(c => !(m.caps || []).includes(c));
    if (miss.length) reasons.push('قابلیت ندارد: ' + miss.map(c => CAPS[c]).join('، '));
    Object.values(fileStatus(m, listing)).forEach(f => {
      if (!f.have) reasons.push('فایل ندارد: ' + f.name);
      else if (!f.ok) reasons.push('حجم فایل نمی‌خواند: ' + f.name);
    });
    return { ok: reasons.length === 0, reasons };
  }
  function eligible(m, role, listing) { return eligibleNeed(m, ROLES[role].need, listing); }

  function estimateRamMb(m, listing) {
    const fs = fileStatus(m, listing);
    const bytes = Object.values(fs).reduce((a, f) => a + (f.bytes || f.expected || 0), 0);
    return Math.round(bytes * 1.25 / 1048576 + 300);
  }

  function validateRoles(roles, models, lib, mode) {
    mode = MODES[mode] ? mode : 'loop';
    const errors = [], warnings = [], info = [], need = MODES[mode].roles;
    const get = id => models.find(m => m.id === id);
    Object.keys(ROLES).forEach(role => {
      const required = need.includes(role), used = required || (role === 'editor' && mode !== 'direct');
      if (!used) return;
      const id = roles[role];
      if (!id) { if (required) errors.push('نقش «' + ROLES[role].title + '» انتخاب نشده'); return; }
      const m = get(id);
      if (!m) { errors.push('مدل نقش «' + ROLES[role].title + '» پیدا نشد'); return; }
      const e = eligible(m, role, lib[m.id]);
      if (!e.ok) errors.push('«' + m.name + '» برای «' + ROLES[role].title + '» مناسب نیست: ' + e.reasons.join('؛ '));
    });
    if (mode === 'direct') info.push('حالت مستقیم: فقط «تولید تصویر» لازم است.');
    else {
      if (roles.supervisor && roles.supervisor === roles.critic) info.push('سرپرست و نقدکننده یکی است: تصمیم‌گیری داخل مرحله‌ی نقد انجام می‌شود و یک جابه‌جایی مدل کمتر دارید.');
      if (roles.editor && roles.editor === roles.generator) info.push('تولید و ویرایش با یک مدل انجام می‌شود (بدون جابه‌جایی).');
      if (!roles.editor) info.push('بدون ویرایشگر: اگر نقد «ویرایش» بخواهد، تصویر با پرامپت اصلاح‌شده دوباره ساخته می‌شود.');
    }
    return { ok: errors.length === 0, errors, warnings, info };
  }

  // ---------- prompts and commands ----------
  const chatml = (system, user, emptyThink) =>
    '<|im_start|>system\n' + system + '<|im_end|>\n<|im_start|>user\n' + user + '<|im_end|>\n<|im_start|>assistant\n' + (emptyThink ? '<think>\n\n</think>\n\n' : '');
  function buildLlmPrompt(m, system, user, think) {
    if (m.runtime === 'llama') return chatml(system, user, !!m.thinkBlock && !think);
    return system + '\n\n' + user; // llama-mtmd-cli applies the model's own chat template
  }
  const splitExtra = s => (s || '').trim().split(/\s+/).filter(Boolean);
  function splitThink(raw) {
    const s = String(raw || ''), i = s.indexOf('<think>');
    if (i < 0) return { think: '', answer: s.trim() };
    const after = s.slice(i + 7), e = after.indexOf('</think>');
    if (e < 0) return { think: after.trim(), answer: s.slice(0, i).trim() };
    return { think: after.slice(0, e).trim(), answer: (s.slice(0, i) + after.slice(e + 8)).trim() };
  }
  function extractJson(text, keys) {
    const s = String(text || ''), found = [];
    for (let i = 0; i < s.length; i++) {
      if (s[i] !== '{') continue;
      let depth = 0, inStr = false, esc = false;
      for (let j = i; j < s.length; j++) {
        const c = s[j];
        if (inStr) { if (esc) esc = false; else if (c === '\\') esc = true; else if (c === '"') inStr = false; continue; }
        if (c === '"') inStr = true;
        else if (c === '{') depth++;
        else if (c === '}') {
          depth--;
          if (depth === 0) {
            try { const o = JSON.parse(s.slice(i, j + 1)); if (o && typeof o === 'object' && (!keys || keys.some(k => k in o))) found.push(o); } catch (e) {}
            i = j; break;
          }
        }
      }
    }
    return found.length ? found[found.length - 1] : null;
  }

  const tail = (s, n) => String(s || '').trim().split('\n').slice(-n).join('\n');
  const pathOf = (ctx, m, name) => ctx.libRoot + '/' + m.id + '/' + name;

  // ---------- one model call = one process (process exit = model "off") ----------
  async function runLlm(ctx, model, system, user, opt) {
    const S = ctx.settings, fs = fileStatus(model, ctx.lib[model.id]), rt = RUNTIMES[model.runtime];
    const prompt = opt.raw != null ? String(opt.raw) : buildLlmPrompt(model, system, user, opt.think);
    const args = ['-m', pathOf(ctx, model, fs.main.name), '-p', prompt, '-n', String(opt.n || 256), '-t', String(S.threads), '-c', String(S.ctx), '--temp', String(opt.temp != null ? opt.temp : S.temp)];
    if (model.runtime === 'mtmd') {
      args.push('--mmproj', pathOf(ctx, model, fs.mmproj.name));
      if (opt.image) args.push('--image', opt.image);
    }
    if (opt.schema && model.runtime !== 'mtmd') args.push('--json-schema', JSON.stringify(opt.schema));
    splitExtra(S.extra[model.runtime]).forEach(a => args.push(a));
    splitExtra(model.extraArgs).forEach(a => args.push(a));
    const T = model.runtime === 'llama' ? toolPlan.oneshot : model.runtime === 'mtmd' ? toolPlan.mtmd : { name: rt.tool, prefix: [] };
    const r = await ctx.tools.run(T.name, T.prefix.concat(args), { timeoutSec: S.timeoutLlm });
    if (r.timeout) throw new Error('زمان اجرای مدل تمام شد');
    if (r.code !== 0) throw new Error('کد خروج ' + r.code + ': ' + tail(r.err, 4));
    return { text: r.out.trim(), ms: r.ms, args, err: r.err };
  }

  async function runSd(ctx, model, o) {
    const S = ctx.settings, fs = fileStatus(model, ctx.lib[model.id]), p = genParams(model, S);
    // Turbo/LCM img2img needs steps * strength >= 1
    const steps = (o.image && (p.family === 'turbo' || p.family === 'lcm')) ? Math.max(p.steps, Math.ceil(1 / S.strength)) : p.steps;
    const args = ['-m', pathOf(ctx, model, fs.main.name), '-p', o.prompt, '-o', o.out, '-W', String(p.size), '-H', String(p.size),
      '--steps', String(steps), '--cfg-scale', String(p.cfg), '--sampling-method', p.sampler, '--seed', String(o.seed), '-t', String(S.threads)];
    if (p.negative) args.push('-n', p.negative);
    if (o.image) args.push('-i', o.image, '--strength', String(S.strength));
    splitExtra(S.extra.sd).forEach(a => args.push(a));
    const r = await ctx.tools.run('sd-cli', args, { timeoutSec: S.timeoutSd });
    if (r.timeout) throw new Error('زمان ساخت تصویر تمام شد');
    if (r.code !== 0) throw new Error('کد خروج ' + r.code + ': ' + tail(r.err, 4));
    const img = await ctx.tools.readImage(o.out);
    if (String(img).startsWith('error:')) throw new Error('فایل تصویر ساخته نشد (' + img + '): ' + tail(r.err, 3));
    return { dataUrl: img, ms: r.ms, args, params: Object.assign({}, p, { steps, seed: o.seed, edit: !!o.image }) };
  }

  // ---------- prompts for the roles ----------
  const SYS_ART = 'You are an art director who writes prompts for a Stable Diffusion Turbo text-to-image model. The request may be in any language. Write ONE concise English prompt (under 60 words) made of comma-separated visual descriptors: subject, style, colors, lighting, composition. Never ask for text inside the image. Reply with JSON only.';
  const userPlan = request => 'Image request: ' + request + '\nReply with JSON only: {"prompt": "..."}';
  const userCritic = (request, prompt) => 'You are a strict image critic. The user asked for: "' + request + '". The image was generated from this prompt: "' + prompt +
    '". Look at the image carefully. Reply with JSON only: {"analysis": "3-5 sentences: what you see, then what does NOT match the request", "score": 0-10, "problems": ["..."], "decision": "accept or regenerate or edit", "edit_instruction": "short instruction if decision is edit", "prompt": "improved full prompt if decision is not accept"}';
  const userDecide = (request, prompt, report) => 'Image request: ' + request + '\nCurrent prompt: ' + prompt + '\nCritic report (JSON): ' + JSON.stringify(report) +
    '\nDecide the next step. Reply with JSON only: {"decision": "accept or regenerate or edit", "prompt": "new full prompt if not accept", "reason": "short reason"}';

  const normDecision = d => (['accept', 'regenerate', 'edit'].includes(String(d).toLowerCase()) ? String(d).toLowerCase() : null);
  const normScore = s => { const n = Number(s); return isFinite(n) ? Math.max(0, Math.min(10, n)) : null; };

  async function askJson(ctx, model, system, user, keys, opt) {
    let last = null;
    for (let attempt = 0; attempt < 2; attempt++) {
      const r = await runLlm(ctx, model, system, attempt ? user + '\nIMPORTANT: reply with valid JSON only, nothing else.' : user, opt);
      const parts = splitThink(r.text);
      const json = extractJson(parts.answer || r.text, keys);
      last = { json, think: parts.think, raw: r.text, ms: r.ms };
      if (json) return last;
    }
    return last;
  }

  // ---------- the loop ----------
  async function runStudio(ctx) {
    const { request, roles, models, settings: S, tools } = ctx;
    const mode = MODES[ctx.mode] ? ctx.mode : 'loop';
    const emit = ev => { try { ctx.onEvent && ctx.onEvent(ev); } catch (e) {} };
    const stop = () => !!(ctx.shouldStop && ctx.shouldStop());
    const check = validateRoles(roles, models, ctx.lib, mode);
    if (!check.ok) throw new Error(check.errors.join(' | '));
    const M = id => models.find(m => m.id === id);
    const useLoop = mode !== 'direct';
    const gen = M(roles.generator), sup = useLoop ? M(roles.supervisor) : null, cri = useLoop ? M(roles.critic) : null, edi = (useLoop && roles.editor) ? M(roles.editor) : null;
    const run = { id: 'run' + Date.now(), ts: Date.now(), request, mode,
      roles: { supervisor: sup ? sup.name : null, generator: gen.name, critic: cri ? cri.name : null, editor: edi ? edi.name : null },
      rounds: [], phases: [], outputs: [], status: 'running', swaps: 0, final: null };
    const dir = await tools.newRunDir(run.id);
    emit({ type: 'start', run });
    let prevModel = null;

    async function phase(round, role, action, model, fn) {
      const ph = { round, role, action, model: model.name, status: 'run', ms: 0, ramFreeMb: ctx.ram ? await ctx.ram() : null };
      if (prevModel && prevModel !== model.id) run.swaps++;
      prevModel = model.id;
      run.phases.push(ph); emit({ type: 'phase', ph });
      const t0 = Date.now();
      try { const r = await fn(); ph.status = 'done'; ph.ms = Date.now() - t0; emit({ type: 'phase', ph }); return r; }
      catch (e) { ph.status = 'error'; ph.ms = Date.now() - t0; ph.note = String(e.message || e); emit({ type: 'phase', ph }); throw e; }
    }
    function record(round, kind, out, img, seed, prompt) {
      round.path = out; round.seed = seed; round.params = img.params;
      run.outputs.push({ round: round.n, kind, path: out, seed, prompt, params: img.params, model: (kind === 'edit' ? edi : gen).name });
      emit({ type: 'image', round: round.n, kind, path: out, dataUrl: img.dataUrl, seed, params: img.params, prompt });
    }

    const t0 = Date.now();
    try {
      if (!useLoop) {
        // ----- direct: the user's own prompt, several seeds, no LLM involved -----
        const prompt = String(ctx.promptOverride || request).trim();
        emit({ type: 'plan', round: 0, prompt, think: '', parsed: true, user: true });
        const n = Math.max(1, Math.min(6, Math.round(S.count || 1)));
        for (let i = 1; i <= n && !stop(); i++) {
          const seed = seedFor(S, i), round = { n: i, prompt, kind: 'gen', score: null, decision: null, note: '' };
          run.rounds.push(round);
          const out = dir + '/d' + i + '_gen.png';
          const img = await phase(i, 'generator', 'generate', gen, () => runSd(ctx, gen, { prompt, out, seed }));
          record(round, 'gen', out, img, seed, prompt);
          run.final = { round: i, path: out, score: null };
        }
        run.status = stop() ? 'stopped' : 'done';
      } else {
        // ----- 1) first prompt: the user's exact prompt, or written by the supervisor -----
        let prompt;
        if (ctx.promptOverride && String(ctx.promptOverride).trim()) {
          prompt = String(ctx.promptOverride).trim();
          emit({ type: 'plan', round: 0, prompt, think: '', parsed: true, user: true });
        } else {
          const p0 = await phase(0, 'supervisor', 'plan', sup, () => askJson(ctx, sup, SYS_ART, userPlan(request), ['prompt'], { n: S.nPlan, think: S.supThink }));
          prompt = (p0.json && p0.json.prompt ? String(p0.json.prompt) : '').trim() || request;
          emit({ type: 'plan', round: 0, prompt, think: p0.think, parsed: !!p0.json });
        }

        let action = 'generate', imagePath = null, best = null;
        for (let r = 1; r <= S.maxRounds; r++) {
          if (stop()) break;
          const round = { n: r, prompt, kind: null, score: null, decision: null, note: '' };
          run.rounds.push(round);
          const useEdit = action === 'edit' && edi && imagePath;
          const out = dir + '/r' + r + (useEdit ? '_edit' : '_gen') + '.png', seed = seedFor(S, r);
          round.kind = useEdit ? 'edit' : 'gen';
          const img = await phase(r, useEdit ? 'editor' : 'generator', useEdit ? 'edit' : 'generate', useEdit ? edi : gen,
            () => runSd(ctx, useEdit ? edi : gen, { prompt, out, seed, image: useEdit ? imagePath : null }));
          imagePath = out; record(round, round.kind, out, img, seed, prompt);
          if (stop()) break;

          // 2) critic looks at the image
          const cr = await phase(r, 'critic', 'critique', cri, () => askJson(ctx, cri, 'You are a precise visual critic.', userCritic(request, prompt), ['decision', 'score', 'analysis'], { n: S.nCritic, image: out }));
          const cj = cr.json || {};
          const crit = { analysis: String(cj.analysis || (cr.json ? '' : '(پاسخ نقدکننده JSON معتبر نبود)')), score: normScore(cj.score),
            problems: Array.isArray(cj.problems) ? cj.problems.map(String) : [], decision: normDecision(cj.decision), edit_instruction: String(cj.edit_instruction || ''), prompt: String(cj.prompt || '') };
          round.score = crit.score; round.parsed = !!cr.json;
          emit({ type: 'critic', round: r, think: cr.think, raw: cr.raw, ...crit });

          // 3) decision: by the critic itself (same model) or by the supervisor
          let dec = { decision: crit.decision, prompt: crit.prompt, edit_instruction: crit.edit_instruction, by: cri.name };
          if (sup.id !== cri.id) {
            const dr = await phase(r, 'supervisor', 'decide', sup, () => askJson(ctx, sup, SYS_ART, userDecide(request, prompt, crit), ['decision'], { n: S.nPlan, think: S.supThink }));
            const dj = dr.json || {};
            dec = { decision: normDecision(dj.decision) || crit.decision, prompt: String(dj.prompt || crit.prompt || ''), edit_instruction: crit.edit_instruction, by: sup.name, reason: String(dj.reason || '') };
          }

          // 4) rules enforced by the system (the user's own choice wins in manual mode)
          let decision = dec.decision;
          if (!decision) decision = (crit.score != null && crit.score >= S.acceptScore) ? 'accept' : (r === S.maxRounds ? 'accept' : 'regenerate');
          if (mode === 'loop' && crit.score != null && crit.score >= S.acceptScore) decision = 'accept';
          if (mode === 'manual' && ctx.review) {
            const rv = await ctx.review({ round: r, score: crit.score, problems: crit.problems, analysis: crit.analysis, suggested: decision,
              prompt: (dec.prompt && dec.prompt.trim()) || prompt, canEdit: !!edi, isLast: r === S.maxRounds });
            if (!rv || rv.action === 'stop') { run.status = 'stopped'; round.decision = 'stop'; emit({ type: 'decision', round: r, decision: 'stop', by: 'user', reason: '', note: '' }); break; }
            decision = rv.action; round.note = 'تصمیم کاربر';
            if (rv.prompt && rv.prompt.trim()) dec.prompt = rv.prompt.trim();
            dec.by = 'user';
          }
          if (decision === 'edit' && !edi) { decision = 'regenerate'; dec.prompt = (dec.prompt || prompt) + (dec.edit_instruction ? ', ' + dec.edit_instruction : ''); round.note = (round.note ? round.note + ' · ' : '') + 'بدون ویرایشگر: بازسازی'; }
          round.decision = decision;
          emit({ type: 'decision', round: r, decision, by: dec.by, reason: dec.reason || '', note: round.note });

          if (!best || (crit.score != null && crit.score > best.score)) best = { round: r, path: out, score: crit.score == null ? -1 : crit.score };
          if (decision === 'accept') { run.status = 'accepted'; run.final = { round: r, path: out, score: crit.score }; break; }
          if (dec.prompt && dec.prompt.trim()) prompt = dec.prompt.trim();
          action = decision;
        }
        if (!run.final) {
          run.status = (run.status === 'stopped' || stop()) ? 'stopped' : 'max_rounds';
          if (best) run.final = { round: best.round, path: best.path, score: best.score < 0 ? null : best.score };
        }
      }
    } catch (e) {
      run.status = 'error'; run.error = String(e.message || e);
    }
    run.ms = Date.now() - t0;
    emit({ type: 'final', run });
    return run;
  }

  // ---------- starter kits (prerequisites of each studio) ----------
  const KITS = {
    image: { id: 'image', title: 'استودیوی تصویر', models: ['qwen3vl-2b', 'sdturbo-q4'], rolesKey: 'studio_roles',
      roles: { supervisor: 'qwen3vl-2b', generator: 'sdturbo-q4', critic: 'qwen3vl-2b', editor: '' },
      roleText: 'سرپرست و نقدکننده = Qwen3-VL 2B، سازنده = SD-Turbo q4_0، ویرایشگر = بدون.', marginBytes: 1073741824, needTools: ['llama-mtmd-cli', 'sd-cli'],
      extra: 'مجوز SD-Turbo: Stability AI Community License.' },
    code: { id: 'code', title: 'استودیوی کد', models: ['qwen35-4b', 'qwen25coder-3b'], rolesKey: 'code_roles',
      roles: { designer: 'qwen35-4b', coder: 'qwen25coder-3b' },
      roleNeeds: { designer: ['text', 'plan', 'json'], coder: ['text', 'code'] },
      roleTitles: { designer: 'طراح و سرپرست', coder: 'کدنویس' },
      roleText: 'طراح و سرپرست = Qwen3.5 4B، کدنویس = Qwen2.5 Coder 3B.', marginBytes: 1073741824, needTools: ['@oneshot'],
      extra: 'مجوز Qwen2.5 Coder 3B «Qwen Research» است (غیرتجاری)؛ اگر قصد انتشار اپ را داری قبلش بررسی کن.', perfTest: true }
  };
  const KIT = KITS.image;

  // lib: { modelId: [{name, bytes}] } ; rt: result of Tools.runtime() or null
  function kitStatus(lib, rt, kit) {
    kit = kit || KIT;
    const L = lib || {}, files = [];
    kit.models.forEach(id => {
      const m = CATALOG.find(x => x.id === id); if (!m) return;
      const fs = fileStatus(m, L[id]);
      Object.values(fs).forEach(f => {
        const decl = (m.files || []).find(x => x.key === f.key) || {};
        files.push({ modelId: id, modelName: m.name, key: f.key, name: f.name, expected: decl.bytes || 0, have: f.have, haveBytes: f.bytes, ok: f.ok, url: decl.url || '', sha: decl.sha || '' });
      });
    });
    const totalBytes = files.reduce((a, f) => a + f.expected, 0);
    const missingBytes = files.filter(f => !f.ok).reduce((a, f) => a + f.expected, 0);
    const toolNames = rt && rt.tools ? Object.keys(rt.tools) : [];
    const has = n => !!(rt && rt.tools && rt.tools[n] && rt.tools[n].exists);
    const need = kit.needTools || toolNames, toolsMissing = [];
    need.forEach(n => { if (n === '@oneshot') { if (!has('llama-completion') && !has('llama-cli') && !has('llama')) toolsMissing.push('llama-completion'); } else if (n === 'llama-mtmd-cli') { if (!has(n) && !has('llama')) toolsMissing.push(n); } else if (!has(n)) toolsMissing.push(n); });
    const free = rt && typeof rt.freeBytes === 'number' && rt.freeBytes > 0 ? rt.freeBytes : null;
    const needSpace = missingBytes + kit.marginBytes;
    const ramMb = Math.max.apply(null, kit.models.map(id => estimateRamMb(CATALOG.find(x => x.id === id), L[id])));
    const filesOk = files.length > 0 && files.every(f => f.ok);
    const toolsOk = !!rt && toolNames.length > 0 && toolsMissing.length === 0;
    let rolesValid = false, errors = [];
    if (filesOk) {
      if (kit.roleNeeds) {
        Object.keys(kit.roles).forEach(r => {
          const m = CATALOG.find(x => x.id === kit.roles[r]);
          if (!m) { errors.push('مدل نقش «' + kit.roleTitles[r] + '» پیدا نشد'); return; }
          const e = eligibleNeed(m, kit.roleNeeds[r], L[m.id]);
          if (!e.ok) errors.push('«' + m.name + '» برای «' + kit.roleTitles[r] + '» مناسب نیست: ' + e.reasons.join('؛ '));
        });
        rolesValid = errors.length === 0;
      } else { const rv = validateRoles(kit.roles, CATALOG, L, 'loop'); rolesValid = rv.ok; errors = rv.errors; }
    }
    return { files, totalBytes, missingBytes, toolNames, toolsMissing, toolsOk, free, need: needSpace, spaceOk: free == null ? null : free >= needSpace, ramMb, filesOk,
      rolesValid, ready: filesOk && toolsOk, errors };
  }

  // Parse llama.cpp timing lines from stderr (decode speed, load time). Returns nulls when absent.
  function parsePerf(err) {
    const s = String(err || ''), out = { decodeTps: null, promptTps: null, loadMs: null, decodeTokens: null };
    let m = s.match(/^(?!.*prompt)[^\n]*\beval time\s*=\s*[\d.]+\s*ms\s*\/\s*(\d+)\s*(?:runs|tokens)[^\n]*?([\d.]+)\s*tokens per second/im);
    if (m) { out.decodeTokens = +m[1]; out.decodeTps = +m[2]; }
    m = s.match(/prompt eval time\s*=\s*[\d.]+\s*ms\s*\/\s*\d+\s*(?:tokens|runs)[^\n]*?([\d.]+)\s*tokens per second/i);
    if (m) out.promptTps = +m[1];
    m = s.match(/load time\s*=\s*([\d.]+)\s*ms/i);
    if (m) out.loadMs = +m[1];
    return out;
  }

  // ---------- bridges ----------
  function nativeTools(T) {
    const jobs = {}, libListeners = []; let n = 0;
    window.onToolEvent = ev => {
      const j = jobs[ev.job]; if (!j) return;
      if (ev.type === 'out') { j.out += ev.text; if (j.onChunk) j.onChunk('out', ev.text); }
      else if (ev.type === 'err') { j.err += ev.text; if (j.onChunk) j.onChunk('err', ev.text); }
      else { delete jobs[ev.job]; j.resolve({ code: ev.code, out: j.out, err: j.err + (ev.text || ''), ms: ev.ms, timeout: ev.type === 'timeout' }); }
    };
    window.onLibEvent = ev => libListeners.forEach(f => f(ev));
    return {
      native: true,
      runtime: () => JSON.parse(T.runtime()), lib: () => JSON.parse(T.lib()),
      libImport: id => T.libImport(id), libDelete: id => T.libDelete(id), onLib: f => libListeners.push(f),
      libVerify: (id, file) => { if (typeof T.libVerify !== 'undefined') T.libVerify(id, file); else libListeners.forEach(f => f({ type: 'verify_error', modelId: id, file, msg: 'نسخهٔ اپ این قابلیت را ندارد' })); },
      run: (tool, args, o) => new Promise(resolve => {
        const job = 'j' + (++n) + '_' + Date.now();
        jobs[job] = { out: '', err: '', resolve, onChunk: o && o.onChunk };
        T.run(job, tool, JSON.stringify(args), (o && o.timeoutSec) || 0);
      }),
      cancelAll: () => Object.keys(jobs).forEach(j => T.cancel(j)),
      readImage: p => Promise.resolve(T.readImage(p)), saveImage: (p, name) => T.saveImage(p, name),
      newRunDir: id => Promise.resolve(T.newRunDir(id)), openUrl: u => T.openUrl(u),
      studioInfo: () => (typeof T.studioInfo !== 'undefined' ? JSON.parse(T.studioInfo()) : { bytes: 0, files: 0 }),
      clearStudio: () => { if (typeof T.clearStudio !== 'undefined') T.clearStudio(); }
    };
  }

  // Simulated tools for the browser preview and for Node tests.
  function mockTools(script) {
    const sc = Object.assign({ critic: [{ score: 4, decision: 'regenerate' }, { score: 8, decision: 'accept' }], delay: 150 }, script || {});
    const images = {}, mockLibL = []; let critN = 0, imgN = 0;
    const wait = ms => new Promise(r => setTimeout(r, sc.delay != null ? Math.min(ms, sc.delay) : ms));
    const svg = k => { const c = ['#00e5cc', '#ffb020', '#6aa6ff', '#ff6b9a'][k % 4];
      return 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="256" height="256"><rect width="256" height="256" fill="#0b1418"/><circle cx="128" cy="128" r="' + (50 + (k % 3) * 20) + '" fill="' + c + '"/><text x="12" y="24" fill="#fff" font-size="14">mock #' + k + '</text></svg>'); };
    const arg = (a, f) => { const i = a.indexOf(f); return i >= 0 ? a[i + 1] : ''; };
    return {
      native: false,
      runtime: () => ({ nativeDir: '/mock', libRoot: '/mock/lib', studioRoot: '/mock/studio', abi: 'mock', freeBytes: 20 * 1073741824, tools: { 'llama-cli': { exists: true, bytes: 1 }, 'llama-completion': { exists: true, bytes: 1 }, 'llama': { exists: true, bytes: 1 }, 'llama-mtmd-cli': { exists: true, bytes: 1 }, 'sd-cli': { exists: true, bytes: 1 } } }),
      lib: () => CATALOG.map(m => ({ id: m.id, files: m.flexible ? Object.values(m.hint || {}).map(n => ({ name: n, bytes: 1000 })) : m.files.map(f => ({ name: f.name, bytes: f.bytes || 1000 })) })),
      libImport: () => {}, libDelete: () => {}, onLib: f => { mockLibL.push(f); },
      libVerify: (id, file) => setTimeout(() => mockLibL.forEach(f => f({ type: 'verify', modelId: id, file, bytes: 1000, msg: ((CATALOG.find(m => m.id === id) || { files: [] }).files.find(x => x.name === file) || {}).sha || 'mock' })), 200),
      newRunDir: async id => '/mock/studio/' + id,
      cancelAll: () => {}, openUrl: () => {}, saveImage: () => 'ok:mock.png', studioInfo: () => ({ bytes: 1500000, files: 4 }), clearStudio: () => {},
      readImage: async p => images[p] || 'error:missing',
      run: async (tool, args) => {
        await wait(800);
        if (tool === 'sd-cli') { const o = arg(args, '-o'); images[o] = svg(++imgN); return { code: 0, out: '', err: 'mock sd', ms: 800 }; }
        if (tool === '--fail') return { code: 1, out: '', err: 'boom', ms: 1 };
        const p = arg(args, '-p');
        if (/Decide the next step/.test(p)) return { code: 0, ms: 500, err: '', out: '{"decision":"regenerate","prompt":"a cozy wooden cabin in a snowy forest, warm window light, dusk, sharp focus","reason":"colors are off"}' };
        if (/image critic/.test(p)) {
          const c = sc.critic[Math.min(critN++, sc.critic.length - 1)];
          if (c.garbage) return { code: 0, ms: 500, err: '', out: 'I think it looks fine, no JSON here' };
          return { code: 0, ms: 500, err: '', out: '<think>Checking colors and composition against the request.</think>' + JSON.stringify({ analysis: 'I see a colored circle on a dark background. It does not show a cabin.', score: c.score, problems: ['no cabin', 'no snow'], decision: c.decision, edit_instruction: 'add a small cabin and snow', prompt: 'a cozy wooden cabin in snowy forest, warm light' }) };
        }
        if (/art director/.test(p)) return { code: 0, ms: 400, err: '', out: '{"prompt":"a cozy wooden cabin in a snowy forest, warm window light, dusk, detailed"}' };
        return { code: 0, ms: 100, err: '', out: 'OK' };
      }
    };
  }

  return { CAPS, ROLES, RUNTIMES, CATALOG, KIT, KITS, kitStatus, planTools, getToolPlan, pickOneShot, parseSubcommands, detectSub, parsePerf, eligibleNeed, DEFAULTS, FAMILIES, SAMPLERS, MODES, genParams, seedFor, validateModelDef, fileStatus, eligible, estimateRamMb, validateRoles,
    chatml, buildLlmPrompt, splitThink, extractJson, runLlm, runSd, runStudio, nativeTools, mockTools };
})();
if (typeof module !== 'undefined') module.exports = StudioCore;
