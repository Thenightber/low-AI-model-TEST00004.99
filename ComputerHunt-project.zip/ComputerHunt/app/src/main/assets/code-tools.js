// Code tools for the coding studio. Model-facing results are English text; UI labels are Persian.
// Everything except runPage/harness is pure (no DOM), so it is tested in Node.
const CodeTools = (() => {
  'use strict';
  const LIM = { out: 3500, readLines: 150, matches: 40, map: 100, undo: 30, undoBytes: 400000 };
  const cap = (s, n) => { s = String(s); return s.length > n ? s.slice(0, n) + '\n...(truncated, ' + (s.length - n) + ' more chars)' : s; };
  const splitLines = t => String(t).split('\n');
  const numbered = (arr, from) => arr.map((l, i) => (from + i) + '| ' + l).join('\n');
  const ext = p => { const m = /\.([a-z0-9]+)$/i.exec(p || ''); return m ? m[1].toLowerCase() : ''; };
  const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const lineOf = (text, idx) => { let n = 1; for (let i = 0; i < idx && i < text.length; i++) if (text.charCodeAt(i) === 10) n++; return n; };
  const fail = (text, extra) => Object.assign({ ok: false, text: String(text) }, extra || {});
  const done = (text, extra) => Object.assign({ ok: true, text: cap(text, LIM.out) }, extra || {});

  // ---------- workspace ----------
  function newWs() { return { files: {}, undo: [] }; }
  function normPath(p) {
    p = String(p == null ? '' : p).trim().replace(/\\/g, '/').replace(/^\.?\//, '').replace(/\/{2,}/g, '/');
    if (!p || p.split('/').some(x => x === '..' || x === '')) return '';
    return p;
  }
  function snapshot(ws, path, label, group) {
    ws.undo.push({ path, before: Object.prototype.hasOwnProperty.call(ws.files, path) ? ws.files[path] : null, label: label || '', group: group || 0 });
    let bytes = ws.undo.reduce((a, u) => a + (u.before ? u.before.length : 0), 0);
    while (ws.undo.length > LIM.undo || (bytes > LIM.undoBytes && ws.undo.length > 1)) { const u = ws.undo.shift(); bytes -= u.before ? u.before.length : 0; }
  }
  function wsWrite(ws, path, text, label, group) { snapshot(ws, path, label, group); ws.files[path] = String(text); }
  function undoOne(ws, u) { if (u.before == null) delete ws.files[u.path]; else ws.files[u.path] = u.before; }
  function wsUndo(ws) {
    const u = ws.undo.pop(); if (!u) return null;
    undoOne(ws, u);
    if (u.group) { u.paths = [u.path]; while (ws.undo.length && ws.undo[ws.undo.length - 1].group === u.group) { const v = ws.undo.pop(); undoOne(ws, v); u.paths.push(v.path); } }
    return u;
  }
  const wsToJSON = ws => JSON.stringify({ files: ws.files });
  function wsFromJSON(s) { const ws = newWs(); try { const o = JSON.parse(s); if (o && o.files && typeof o.files === 'object') Object.keys(o.files).forEach(k => { if (normPath(k) && typeof o.files[k] === 'string') ws.files[normPath(k)] = o.files[k]; }); } catch (e) {} return ws; }
  function suggest(ws, path) {
    const base = String(path).split('/').pop().toLowerCase();
    return Object.keys(ws.files).filter(f => f.toLowerCase().includes(base) || base.includes(f.split('/').pop().toLowerCase())).slice(0, 5);
  }
  function needFile(ws, path) {
    const p = normPath(path);
    if (!p) return { err: fail('Invalid path "' + path + '". Use a relative path like "src/app.js".') };
    if (!Object.prototype.hasOwnProperty.call(ws.files, p)) {
      const s = suggest(ws, p), all = Object.keys(ws.files);
      return { err: fail('File not found: ' + p + '. ' + (s.length ? 'Did you mean: ' + s.join(', ') + '? ' : '') + 'Files: ' + (all.join(', ') || '(none)')) };
    }
    return { p, text: ws.files[p] };
  }

  // ---------- JS masking: blank out strings, comments, regex and template literals (same length, newlines kept) ----------
  const KW_BEFORE_REGEX = /^(return|typeof|case|do|else|in|of|void|delete|throw|new|instanceof|yield|await)$/;
  function maskJs(src) {
    src = String(src); const n = src.length, out = new Array(n); let i = 0, last = { t: '', v: '' };
    const blank = (a, b) => { for (let k = a; k < b; k++) out[k] = src[k] === '\n' ? '\n' : ' '; };
    while (i < n) {
      const c = src[i], d = src[i + 1];
      if (c === '/' && d === '/') { let j = src.indexOf('\n', i); if (j < 0) j = n; blank(i, j); i = j; continue; }
      if (c === '/' && d === '*') { let j = src.indexOf('*/', i + 2); j = j < 0 ? n : j + 2; blank(i, j); i = j; continue; }
      if (c === '"' || c === "'") {
        let j = i + 1; while (j < n && src[j] !== c && src[j] !== '\n') { if (src[j] === '\\') j++; j++; }
        j = Math.min(j + 1, n); blank(i, j); i = j; last = { t: 'a', v: '' }; continue;
      }
      if (c === '`') {
        let j = i + 1, depth = 0;
        while (j < n) {
          const x = src[j];
          if (x === '\\') { j += 2; continue; }
          if (depth === 0 && x === '`') break;
          if (x === '$' && src[j + 1] === '{') { depth++; j += 2; continue; }
          if (depth > 0 && x === '{') depth++;
          else if (depth > 0 && x === '}') depth--;
          j++;
        }
        j = Math.min(j + 1, n); blank(i, j); i = j; last = { t: 'a', v: '' }; continue;
      }
      if (c === '/') {
        const regexOk = last.t === '' || (last.t === 'p' && '(,=:[!&|?{;+-*%<>~^'.includes(last.v)) || (last.t === 'w' && KW_BEFORE_REGEX.test(last.v));
        if (regexOk) {
          let j = i + 1, inClass = false;
          while (j < n && src[j] !== '\n') { const x = src[j]; if (x === '\\') { j += 2; continue; } if (x === '[') inClass = true; else if (x === ']') inClass = false; else if (x === '/' && !inClass) break; j++; }
          if (j < n && src[j] === '/') { j++; while (j < n && /[a-z]/i.test(src[j])) j++; blank(i, j); i = j; last = { t: 'a', v: '' }; continue; }
        }
      }
      if (/[A-Za-z_$]/.test(c)) { let j = i + 1; while (j < n && /[\w$]/.test(src[j])) j++; for (let k = i; k < j; k++) out[k] = src[k]; last = { t: 'w', v: src.slice(i, j) }; i = j; continue; }
      if (/[0-9]/.test(c)) { let j = i + 1; while (j < n && /[\w.]/.test(src[j])) j++; for (let k = i; k < j; k++) out[k] = src[k]; last = { t: 'a', v: '' }; i = j; continue; }
      out[i] = c;
      if (!/\s/.test(c)) last = { t: (c === ')' || c === ']' || c === '}') ? 'a' : 'p', v: c };
      i++;
    }
    return out.join('');
  }

  // ---------- JS checks ----------
  function bracketIssues(src, off) {
    const m = maskJs(src), st = [], errs = []; let line = 1 + (off || 0);
    const pair = { ')': '(', ']': '[', '}': '{' };
    for (let i = 0; i < m.length && errs.length < 5; i++) {
      const c = m[i];
      if (c === '\n') line++;
      else if (c === '(' || c === '[' || c === '{') st.push({ c, line });
      else if (c === ')' || c === ']' || c === '}') {
        const top = st.pop();
        if (!top) errs.push('Unexpected "' + c + '" at line ' + line + ' (nothing to close).');
        else if (top.c !== pair[c]) errs.push('Mismatch: "' + top.c + '" opened at line ' + top.line + ' but closed by "' + c + '" at line ' + line + '.');
      }
    }
    st.slice(-3).forEach(o => errs.length < 6 && errs.push('Unclosed "' + o.c + '" opened at line ' + o.line + '.'));
    return errs;
  }
  function checkJsText(src) {
    const errs = bracketIssues(src);
    if (!errs.length && !/^\s*(import|export)\b/m.test(src) && !/\bawait\b/.test(maskJs(src))) {
      try { new Function(src); } catch (e) { errs.push('SyntaxError: ' + e.message + ' (line unknown; look near the last edit).'); }
    }
    return errs;
  }
  // Wrap the condition of every while / three-part for loop with __lgc(cond): a time-based guard that throws on a runaway loop.
  // Works for braced and braceless bodies; for-of/for-in are not wrapped (they walk finite collections). Only inserts text, so line numbers stay the same.
  function instrumentLoops(src) {
    src = String(src); const m = maskJs(src), ins = []; let count = 0, x;
    const re = /\b(for|while)\b\s*(?:await\s*)?\(/g;
    while ((x = re.exec(m))) {
      const open = x.index + x[0].length; let i = open, depth = 1; const semis = [];
      while (i < m.length && depth > 0) { const c = m[i]; if (c === '(' || c === '[' || c === '{') depth++; else if (c === ')' || c === ']' || c === '}') depth--; else if (c === ';' && depth === 1) semis.push(i); i++; }
      if (depth !== 0) continue;
      const close = i - 1;
      if (x[1] === 'while') { ins.push([open, '__lgc(']); ins.push([close, ')']); count++; }
      else if (semis.length === 2) {
        const a = semis[0] + 1, b = semis[1];
        if (m.slice(a, b).trim() === '') ins.push([a, ' __lgc(true)']); else { ins.push([a, ' __lgc(']); ins.push([b, ')']); }
        count++;
      }
    }
    let out = src; ins.sort((p, q) => q[0] - p[0]).forEach(([k, t]) => { out = out.slice(0, k) + t + out.slice(k); });
    return { code: out, count };
  }

  // ---------- list / read / search / map ----------
  function toolListFiles(ws) {
    const k = Object.keys(ws.files).sort();
    if (!k.length) return done('Workspace is empty. Use write_file to create files.');
    return done(k.map(p => p + '  (' + splitLines(ws.files[p]).length + ' lines, ' + ws.files[p].length + ' chars)').join('\n'));
  }
  function toolReadFile(ws, a) {
    const f = needFile(ws, a.path); if (f.err) return f.err;
    const L = splitLines(f.text), total = L.length;
    let from = Math.max(1, Math.floor(a.from || 1)), to = Math.floor(a.to || (from + 79));
    if (to < from) to = from; if (to > total) to = total;
    if (from > total) return fail('File ' + f.p + ' has only ' + total + ' lines.');
    let truncated = false;
    if (to - from + 1 > LIM.readLines) { to = from + LIM.readLines - 1; truncated = true; }
    let body = numbered(L.slice(from - 1, to), from);
    if (body.length > LIM.out) { body = cap(body, LIM.out); truncated = true; }
    return done(f.p + ' lines ' + from + '-' + to + ' of ' + total + (truncated ? ' (truncated: ask for a smaller range)' : '') + '\n' + body);
  }
  function toolSearch(ws, a) {
    const q = String(a.query == null ? '' : a.query); if (!q) return fail('query is empty.');
    let re;
    try {
      let pat = a.regex ? q : q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      if (a.word && !a.regex) pat = '\\b' + pat + '\\b';
      re = new RegExp(pat, a.case ? '' : 'i');
    } catch (e) { return fail('Invalid regex: ' + e.message); }
    const ctx = Math.max(0, Math.min(5, a.context == null ? 1 : Math.floor(a.context)));
    const prefix = a.path ? normPath(a.path) : '';
    const files = Object.keys(ws.files).sort().filter(p => !prefix || p === prefix || p.startsWith(prefix.replace(/\/?$/, '/')));
    if (prefix && !files.length) return fail('No file matches path "' + a.path + '". Files: ' + (Object.keys(ws.files).join(', ') || '(none)'));
    let total = 0, shown = 0, fileCount = 0; const blocks = [];
    files.forEach(p => {
      const L = splitLines(ws.files[p]), hits = [];
      L.forEach((l, i) => { if (re.test(l)) hits.push(i); });
      if (!hits.length) return;
      fileCount++; total += hits.length;
      const ranges = [];
      hits.forEach(h => {
        if (shown >= LIM.matches) return; shown++;
        const a1 = Math.max(0, h - ctx), b1 = Math.min(L.length - 1, h + ctx), last = ranges[ranges.length - 1];
        if (last && a1 <= last[1] + 1) last[1] = b1; else ranges.push([a1, b1]);
      });
      if (!ranges.length) return;
      const hs = new Set(hits);
      blocks.push('# ' + p + '\n' + ranges.map(([x, y]) => { const o = []; for (let i = x; i <= y; i++) o.push((hs.has(i) ? '> ' : '  ') + (i + 1) + '| ' + (L[i].length > 200 ? L[i].slice(0, 200) + '...' : L[i])); return o.join('\n'); }).join('\n  ...\n'));
    });
    if (!total) return done('No matches for "' + q + '" in ' + files.length + ' file(s).');
    return done(total + ' match(es) in ' + fileCount + ' file(s)' + (shown < total ? ' (showing first ' + shown + ')' : '') + ':\n' + blocks.join('\n'));
  }

  const JS_SKIP = /^(if|for|while|switch|catch|function|return|else|do|try|with|typeof|new)$/;
  function mapJsLine(l, ln, out, indentBase) {
    let m;
    if ((m = /^\s*(?:export\s+)?(?:default\s+)?(async\s+)?function\s*\*?\s*([\w$]+)\s*\(([^)]*)/.exec(l))) return out.push('L' + ln + ' function ' + m[2] + '(' + m[3].trim() + ')');
    if ((m = /^\s*(?:export\s+)?(?:const|let|var)\s+([\w$]+)\s*=\s*(?:async\s*)?(\([^)]*\)|[\w$]+)\s*=>/.exec(l))) return out.push('L' + ln + ' const ' + m[1] + ' = ' + m[2] + ' =>');
    if ((m = /^\s*(?:const|let|var)\s+([\w$]+)\s*=\s*(?:async\s+)?function\b/.exec(l))) return out.push('L' + ln + ' function-expr ' + m[1]);
    if ((m = /^\s*(?:export\s+)?(?:default\s+)?class\s+([\w$]+)(\s+extends\s+[\w$.]+)?/.exec(l))) return out.push('L' + ln + ' class ' + m[1] + (m[2] || ''));
    if ((m = /^(\s{1,}|\t+)(?:static\s+)?(?:async\s+)?(?:get\s+|set\s+)?([\w$]+)\s*\(([^)]*)\)\s*\{\s*$/.exec(l)) && !JS_SKIP.test(m[2])) return out.push('L' + ln + '   method ' + m[2] + '(' + m[3].trim() + ')');
    if ((m = /^(?:const|let|var)\s+([\w$]+)\s*=/.exec(l))) return out.push('L' + ln + ' ' + l.trim().split(/\s*=/)[0]);
    if ((m = /([\w$.#'"\[\]-]+)\.addEventListener\(\s*['"]([\w-]+)/.exec(l))) out.push('L' + ln + '   listener ' + m[2] + ' on ' + m[1]);
    if (/\b(setInterval|requestAnimationFrame)\s*\(/.test(l)) out.push('L' + ln + '   loop: ' + /(setInterval|requestAnimationFrame)/.exec(l)[1]);
  }
  function mapCssLine(l, ln, out) {
    const m = /^\s*([^{}\/][^{]*)\{/.exec(l);
    if (m && !/^\s*[\w-]+\s*:/.test(l)) out.push('L' + ln + ' ' + m[1].trim().slice(0, 80));
  }
  function toolCodeMap(ws, a) {
    const f = needFile(ws, a.path); if (f.err) return f.err;
    const L = splitLines(f.text), out = [], e = ext(f.p);
    if (e === 'js' || e === 'mjs' || e === 'ts') L.forEach((l, i) => mapJsLine(l, i + 1, out));
    else if (e === 'css') L.forEach((l, i) => mapCssLine(l, i + 1, out));
    else if (e === 'md') L.forEach((l, i) => { if (/^#{1,6}\s/.test(l)) out.push('L' + (i + 1) + ' ' + l.trim()); });
    else if (e === 'html' || e === 'htm') {
      let mode = '';
      L.forEach((l, i) => {
        const ln = i + 1;
        if (mode === 'js') { if (/<\/script/i.test(l)) { out.push('L' + ln + ' </script>'); mode = ''; } else mapJsLine(l, ln, out); return; }
        if (mode === 'css') { if (/<\/style/i.test(l)) { out.push('L' + ln + ' </style>'); mode = ''; } else mapCssLine(l, ln, out); return; }
        let m;
        if ((m = /<script\b([^>]*)>/i.exec(l))) { const src = /src\s*=\s*["']([^"']+)/i.exec(m[1]); out.push('L' + ln + ' <script' + (src ? ' src=' + src[1] : ' inline') + '>'); if (!src && !/<\/script/i.test(l)) mode = 'js'; }
        else if (/<style\b/i.test(l)) { out.push('L' + ln + ' <style>'); if (!/<\/style/i.test(l)) mode = 'css'; }
        else if ((m = /<link\b[^>]*href\s*=\s*["']([^"']+)/i.exec(l))) out.push('L' + ln + ' <link ' + m[1] + '>');
        const idm = l.match(/<([a-z][\w-]*)\b[^>]*\bid\s*=\s*["']([^"']+)["']/gi);
        if (idm && !/<script|<style/i.test(l)) idm.forEach(s => { const mm = /<([a-z][\w-]*)\b[^>]*\bid\s*=\s*["']([^"']+)["']/i.exec(s); out.push('L' + ln + ' <' + mm[1] + ' id=' + mm[2] + '>'); });
      });
    } else return fail('code_map supports .js .html .css .md files. For ' + f.p + ' use read_file.');
    if (!out.length) return done(f.p + ' (' + L.length + ' lines): no symbols found.');
    const shown = out.slice(0, LIM.map);
    return done(f.p + ' (' + L.length + ' lines), ' + out.length + ' symbols:\n' + shown.join('\n') + (out.length > shown.length ? '\n...(' + (out.length - shown.length) + ' more; use search)' : ''));
  }

  // ---------- edit / write / delete / undo ----------
  function findAll(text, find) { const r = []; let i = 0; while ((i = text.indexOf(find, i)) >= 0) { r.push(i); i += Math.max(1, find.length); } return r; }
  function toolEditFile(ws, a) {
    const f = needFile(ws, a.path); if (f.err) return f.err;
    const edits = Array.isArray(a.edits) ? a.edits : [];
    if (!edits.length) return fail('edits is empty. Provide [{"find": "exact old text", "replace": "new text"}].');
    let text = f.text; const report = [];
    for (let i = 0; i < edits.length; i++) {
      const e = edits[i] || {}, find = e.find == null ? '' : String(e.find), rep = e.replace == null ? '' : String(e.replace);
      if (!find) return fail('Edit #' + (i + 1) + ': "find" is empty. Nothing was changed.');
      const hits = findAll(text, find);
      if (!hits.length) {
        const first = find.split('\n')[0].trim(), L = splitLines(text), near = first ? L.findIndex(l => l.includes(first)) : -1;
        return fail('Edit #' + (i + 1) + ': text not found (exact match needed, including spaces and indentation). ' + (near >= 0 ? 'Closest line ' + (near + 1) + ': ' + L[near].slice(0, 160) + '. Use read_file on that range and copy the text exactly.' : 'Use search to locate it first.') + ' Nothing was changed.');
      }
      if (hits.length > 1 && !e.all) return fail('Edit #' + (i + 1) + ': found ' + hits.length + ' times (lines ' + hits.slice(0, 8).map(h => lineOf(text, h)).join(', ') + '). Make "find" longer so it is unique, or set "all": true. Nothing was changed.');
      const ln = lineOf(text, hits[0]);
      text = e.all ? text.split(find).join(rep) : text.slice(0, hits[0]) + rep + text.slice(hits[0] + find.length);
      report.push('#' + (i + 1) + ' ok at line ' + ln + (hits.length > 1 ? ' (x' + hits.length + ')' : '') + ': ' + splitLines(find).length + ' line(s) -> ' + splitLines(rep).length + ' line(s)');
    }
    wsWrite(ws, f.p, text, 'edit');
    let note = '';
    if (ext(f.p) === 'js') { const errs = checkJsText(text); note = errs.length ? '\nWARNING after edit: ' + errs.join(' ') : '\nJS check: OK.'; }
    else if (ext(f.p) === 'html') { const h = htmlCheck(ws, f.p); note = h.errors.length ? '\nWARNING after edit: ' + h.errors.slice(0, 3).join(' ') : '\nHTML check: no errors.'; }
    return done(f.p + ' updated (' + splitLines(text).length + ' lines).\n' + report.join('\n') + note, { paths: [f.p] });
  }
  function toolWriteFile(ws, a) {
    const p = normPath(a.path); if (!p) return fail('Invalid path "' + a.path + '".');
    const text = a.text == null ? '' : String(a.text), old = ws.files[p];
    wsWrite(ws, p, text, 'write');
    let warn = '';
    if (old != null && old.length > 400 && text.length < old.length * 0.5) warn = '\nWARNING: the new file is less than half the size of the old one (' + old.length + ' -> ' + text.length + ' chars). If this was not intended, call undo.';
    return done((old == null ? 'Created ' : 'Overwrote ') + p + ' (' + splitLines(text).length + ' lines).' + warn, { paths: [p] });
  }
  // ---------- diff ----------
  function diffText(a, b, ctx) {
    ctx = ctx == null ? 2 : ctx;
    const A = a == null ? [] : splitLines(a), B = splitLines(b == null ? '' : b);
    if (A.length * B.length > 4000000) return '(files too large to diff: ' + A.length + ' -> ' + B.length + ' lines)';
    const n = A.length, mm = B.length, dp = [];
    for (let i = 0; i <= n; i++) dp.push(new Uint16Array(mm + 1));
    for (let i = n - 1; i >= 0; i--) for (let j = mm - 1; j >= 0; j--) dp[i][j] = A[i] === B[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
    const ops = []; let i = 0, j = 0;
    while (i < n && j < mm) { if (A[i] === B[j]) { ops.push([' ', A[i], j + 1]); i++; j++; } else if (dp[i + 1][j] >= dp[i][j + 1]) { ops.push(['-', A[i], j + 1]); i++; } else { ops.push(['+', B[j], j + 1]); j++; } }
    while (i < n) { ops.push(['-', A[i], j + 1]); i++; } while (j < mm) { ops.push(['+', B[j], j + 1]); j++; }
    const keep = new Array(ops.length).fill(false);
    ops.forEach((o, k) => { if (o[0] !== ' ') for (let d = -ctx; d <= ctx; d++) if (ops[k + d]) keep[k + d] = true; });
    const out = []; let skipped = false, changes = 0;
    ops.forEach((o, k) => { if (o[0] !== ' ') changes++; if (!keep[k]) { skipped = true; return; } if (skipped && out.length) out.push('  ...'); skipped = false; out.push(o[0] + ' ' + o[2] + '| ' + o[1]); });
    return changes ? out.join('\n') : '(no differences)';
  }
  function toolDiffLast(ws) {
    if (!ws.undo.length) return fail('No recorded changes to diff.');
    const last = ws.undo[ws.undo.length - 1], group = last.group, items = [last];
    if (group) for (let k = ws.undo.length - 2; k >= 0 && ws.undo[k].group === group; k--) items.push(ws.undo[k]);
    const out = items.map(u => {
      const cur = Object.prototype.hasOwnProperty.call(ws.files, u.path) ? ws.files[u.path] : null;
      if (u.before == null) return '# ' + u.path + ' (new file, ' + splitLines(cur || '').length + ' lines)';
      if (cur == null) return '# ' + u.path + ' (deleted)';
      return '# ' + u.path + ' (' + u.label + ')\n' + diffText(u.before, cur);
    });
    return done(out.join('\n'));
  }
  function toolReplaceLines(ws, a) {
    const f = needFile(ws, a.path); if (f.err) return f.err;
    const L = splitLines(f.text), total = L.length, from = Math.floor(a.from), to = Math.floor(a.to == null ? a.from : a.to);
    if (!(from >= 1) || from > total) return fail('"from" must be between 1 and ' + total + ' (file has ' + total + ' lines).');
    if (!(to >= from) || to > total) return fail('"to" must be between from and ' + total + '.');
    const newL = a.text == null || a.text === '' ? [] : splitLines(String(a.text)), old = L.slice(from - 1, to);
    const text = L.slice(0, from - 1).concat(newL, L.slice(to)).join('\n');
    wsWrite(ws, f.p, text, 'replace_lines');
    let note = '';
    if (ext(f.p) === 'js') { const errs = checkJsText(text); note = errs.length ? '\nWARNING after edit: ' + errs.join(' ') : '\nJS check: OK.'; }
    return done(f.p + ' updated: lines ' + from + '-' + to + ' (' + old.length + ' line(s)) replaced by ' + newL.length + ' line(s). Old text started with: ' + (old[0] || '').trim().slice(0, 80) + note, { paths: [f.p] });
  }
  function toolRenameSymbol(ws, a) {
    const o = String(a.old || ''), n = String(a.new || '');
    if (!/^[A-Za-z_$][\w$-]*$/.test(o) || !/^[A-Za-z_$][\w$-]*$/.test(n)) return fail('"old" and "new" must be plain names (letters, digits, _ $ -).');
    if (o === n) return fail('"old" and "new" are the same.');
    const re = new RegExp('(?<![\\w$-])' + reEsc(o) + '(?![\\w$-])', 'g'), prefix = a.path ? normPath(a.path) : '';
    const files = Object.keys(ws.files).sort().filter(p => /\.(m?js|html?|css)$/i.test(p) && (!prefix || p === prefix || p.startsWith(prefix.replace(/\/?$/, '/'))));
    const group = Date.now() + Math.random(), rep = [], paths = []; let total = 0;
    files.forEach(p => { const c = (ws.files[p].match(re) || []).length; if (!c) return; wsWrite(ws, p, ws.files[p].replace(re, n), 'rename ' + o + '->' + n, group); total += c; rep.push(p + ': ' + c); paths.push(p); });
    if (!total) return fail('"' + o + '" was not found as a whole word in ' + files.length + ' file(s).');
    return done('Renamed "' + o + '" -> "' + n + '": ' + total + ' occurrence(s) in ' + rep.join(', ') + '. Note: strings and comments are included. Undo reverts all files at once.', { paths });
  }

  function toolDeleteFile(ws, a) {
    const f = needFile(ws, a.path); if (f.err) return f.err;
    snapshot(ws, f.p, 'delete'); delete ws.files[f.p];
    return done('Deleted ' + f.p + '. Call undo to restore it.');
  }
  function toolUndo(ws) {
    const u = wsUndo(ws);
    return u ? done('Undid last change (' + u.label + ') on ' + u.path + '.') : fail('Nothing to undo.');
  }

  // ---------- HTML parsing ----------
  const VOID = new Set(['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr']);
  const OPT_CLOSE = new Set(['p', 'li', 'dt', 'dd', 'tr', 'td', 'th', 'thead', 'tbody', 'tfoot', 'option', 'optgroup', 'colgroup', 'html', 'head', 'body']);
  const mkLine = text => {
    const nl = []; for (let i = 0; i < text.length; i++) if (text.charCodeAt(i) === 10) nl.push(i);
    return idx => { let lo = 0, hi = nl.length; while (lo < hi) { const mid = (lo + hi) >> 1; if (nl[mid] < idx) lo = mid + 1; else hi = mid; } return lo + 1; };
  };
  function parseAttrs(s) {
    const a = {}, re = /([^\s"'<>\/=]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+)))?/g; let m;
    while ((m = re.exec(s))) a[m[1].toLowerCase()] = m[2] != null ? m[2] : m[3] != null ? m[3] : m[4] != null ? m[4] : '';
    return a;
  }
  function tokenizeHtml(text) {
    const toks = [], lineAt = mkLine(text), re = /<\!--[\s\S]*?-->|<!doctype[^>]*>|<(\/?)([a-zA-Z][\w:-]*)((?:"[^"]*"|'[^']*'|[^>"'])*)>/gi; let m;
    while ((m = re.exec(text))) {
      if (m[0].startsWith('<!' + '--')) continue;
      if (/^<!doctype/i.test(m[0])) { toks.push({ type: 'doctype', line: lineAt(m.index) }); continue; }
      const tag = m[2].toLowerCase(), closing = !!m[1], rawAttrs = m[3] || '', selfc = /\/\s*$/.test(rawAttrs);
      const t = { type: closing ? 'close' : 'open', tag, attrs: closing ? {} : parseAttrs(rawAttrs.replace(/\/\s*$/, '')), line: lineAt(m.index), start: m.index, end: m.index + m[0].length, selfc };
      toks.push(t);
      if (!closing && (tag === 'script' || tag === 'style') && !selfc) {
        const rest = text.slice(re.lastIndex), cm = new RegExp('</' + tag + '\\s*>', 'i').exec(rest);
        t.inner = cm ? rest.slice(0, cm.index) : rest; t.innerLine = lineAt(re.lastIndex);
        re.lastIndex += cm ? cm.index : rest.length;
      }
    }
    return toks;
  }
  // Walk tokens with an element stack. Returns nodes with depth, plus structure errors.
  function buildTree(toks) {
    const nodes = [], errors = [], st = [];
    const popTo = n => { while (st.length > n) st.pop(); };
    toks.forEach(t => {
      if (t.type === 'open') {
        const top = st[st.length - 1];
        if (top && OPT_CLOSE.has(t.tag) && ((top.tag === t.tag && t.tag !== 'html') || ((t.tag === 'td' || t.tag === 'th') && (top.tag === 'td' || top.tag === 'th')) || (t.tag === 'tr' && (top.tag === 'td' || top.tag === 'th' || top.tag === 'tr')))) {
          st.pop(); if (t.tag === 'tr' && st.length && st[st.length - 1].tag === 'tr') st.pop();
        }
        nodes.push({ tag: t.tag, attrs: t.attrs, line: t.line, depth: st.length, tok: t });
        if (!VOID.has(t.tag) && !t.selfc) st.push({ tag: t.tag, line: t.line });
      } else if (t.type === 'close') {
        let k = -1; for (let i = st.length - 1; i >= 0; i--) if (st[i].tag === t.tag) { k = i; break; }
        if (k < 0) { if (!VOID.has(t.tag)) errors.push('Stray </' + t.tag + '> at line ' + t.line + ' (no matching open tag).'); return; }
        for (let i = st.length - 1; i > k; i--) if (!OPT_CLOSE.has(st[i].tag)) errors.push('<' + st[i].tag + '> opened at line ' + st[i].line + ' is not closed before </' + t.tag + '> at line ' + t.line + '.');
        popTo(k);
      }
    });
    st.forEach(o => { if (!OPT_CLOSE.has(o.tag)) errors.push('Unclosed <' + o.tag + '> opened at line ' + o.line + '.'); });
    return { nodes, errors };
  }
  const dirOf = p => p.includes('/') ? p.slice(0, p.lastIndexOf('/') + 1) : '';
  function resolveRef(base, ref) {
    ref = String(ref).split('#')[0].split('?')[0]; if (!ref) return '';
    const parts = (ref.startsWith('/') ? ref.slice(1) : dirOf(base) + ref).split('/'), out = [];
    parts.forEach(x => { if (x === '..') out.pop(); else if (x && x !== '.') out.push(x); });
    return out.join('/');
  }
  const isExternal = r => /^(https?:)?\/\//i.test(r) || /^(data|mailto|javascript|blob|tel):/i.test(r) || r.startsWith('#') || /[{<]/.test(r);
  const reEsc = s => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const BUILTIN_CALLS = new Set(['alert', 'confirm', 'prompt', 'console', 'this', 'event', 'document', 'window', 'Math', 'history', 'location', 'navigator', 'setTimeout', 'setInterval', 'return', 'if', 'void']);

  function htmlCheck(ws, path) {
    const text = ws.files[path], errors = [], warnings = [], toks = tokenizeHtml(text), tree = buildTree(toks);
    tree.errors.forEach(e => errors.push(e));
    let hasDoctype = false, hasTitle = false, hasViewport = false, hasLang = false; const ids = {}, scripts = [], handlers = [];
    toks.forEach(t => {
      if (t.type === 'doctype') { hasDoctype = true; return; }
      if (t.type !== 'open') return;
      if (t.tag === 'title') hasTitle = true;
      if (t.tag === 'html' && t.attrs.lang) hasLang = true;
      if (t.tag === 'meta' && /viewport/i.test(t.attrs.name || '')) hasViewport = true;
      if (t.attrs.id != null) { if (ids[t.attrs.id]) errors.push('Duplicate id "' + t.attrs.id + '" at lines ' + ids[t.attrs.id] + ' and ' + t.line + '.'); else ids[t.attrs.id] = t.line; }
      Object.keys(t.attrs).forEach(k => { if (/^on[a-z]+$/.test(k)) handlers.push({ line: t.line, code: t.attrs[k] }); });
      const ref = t.tag === 'script' ? t.attrs.src : (t.tag === 'link' ? t.attrs.href : (t.tag === 'img' || t.tag === 'source' || t.tag === 'audio' || t.tag === 'video') ? t.attrs.src : null);
      if (ref && !isExternal(ref)) {
        const target = resolveRef(path, ref);
        if (!Object.prototype.hasOwnProperty.call(ws.files, target)) (t.tag === 'script' || (t.tag === 'link' && /stylesheet/i.test(t.attrs.rel || '')) ? errors : warnings).push('<' + t.tag + '> at line ' + t.line + ' references "' + ref + '" which is not in the workspace.');
        else if (t.tag === 'script') { scripts.push({ label: target, text: ws.files[target], line0: 0 }); }
      }
      if (t.tag === 'script' && !t.attrs.src && t.inner != null) scripts.push({ label: path, text: t.inner, line0: t.innerLine - 1 });
    });
    if (!hasDoctype) warnings.push('Missing <!DOCTYPE html> (browser falls back to quirks mode).');
    if (!hasTitle) warnings.push('Missing <title>.');
    if (!hasViewport) warnings.push('Missing <meta name="viewport"> (bad scaling on phones).');
    if (!hasLang) warnings.push('<html> has no lang attribute.');
    const allJs = scripts.map(s => s.text).join('\n');
    scripts.forEach(s => bracketIssues(s.text, s.line0).forEach(e => errors.push((s.label !== path ? s.label + ': ' : 'inline script: ') + e)));
    const seen = new Set();
    [/getElementById\(\s*['"]([^'"]+)['"]/g, /querySelector(?:All)?\(\s*['"]#([\w-]+)/g, /\$\(\s*['"]#([\w-]+)['"]/g].forEach(re => {
      let m; while ((m = re.exec(allJs))) {
        const id = m[1]; if (seen.has(id) || ids[id] != null) continue; seen.add(id);
        const made = new RegExp('(\\bid\\s*=\\s*["\']?' + reEsc(id) + '|setAttribute\\(\\s*[\'"]id[\'"]\\s*,\\s*[\'"]' + reEsc(id) + ')').test(allJs);
        if (!made) warnings.push('JavaScript looks up id "' + id + '" but no element has that id.');
      }
    });
    handlers.forEach(h => {
      const m = /^\s*(?:return\s+)?([A-Za-z_$][\w$]*)\s*\(/.exec(h.code); if (!m || BUILTIN_CALLS.has(m[1])) return;
      const n = reEsc(m[1]);
      if (!new RegExp('function\\s+' + n + '\\b|\\b' + n + '\\s*=\\s*(?:function|async|\\()|(?:const|let|var)\\s+' + n + '\\b|window\\.' + n + '\\s*=').test(allJs)) warnings.push('Line ' + h.line + ': inline handler calls ' + m[1] + '() but no such function is defined in the scripts.');
    });
    return { errors, warnings, tree };
  }
  function toolHtmlCheck(ws, a) {
    const f = needFile(ws, a.path); if (f.err) return f.err;
    if (!/^(html?|svg)$/.test(ext(f.p))) return fail(f.p + ' is not an HTML file.');
    const r = htmlCheck(ws, f.p), out = [];
    out.push(f.p + ': ' + r.errors.length + ' error(s), ' + r.warnings.length + ' warning(s).');
    r.errors.slice(0, 12).forEach(e => out.push('ERROR: ' + e)); r.warnings.slice(0, 12).forEach(e => out.push('WARN: ' + e));
    if (!r.errors.length && !r.warnings.length) out.push('Structure looks fine.');
    return done(out.join('\n'), { errors: r.errors.length, warnings: r.warnings.length });
  }
  function toolHtmlOutline(ws, a) {
    const f = needFile(ws, a.path); if (f.err) return f.err;
    const t = buildTree(tokenizeHtml(f.text)), maxD = Math.max(1, Math.min(8, Math.floor(a.depth || 4))), out = []; let skipped = 0;
    t.nodes.forEach(n => {
      if (n.tok.type !== 'open' || n.depth > maxD || n.tag === 'html') { if (n.depth > maxD) skipped++; return; }
      const cls = (n.attrs.class || '').trim().split(/\s+/).filter(Boolean).slice(0, 3).join('.');
      out.push('  '.repeat(Math.max(0, n.depth - 1)) + '<' + n.tag + (n.attrs.id ? '#' + n.attrs.id : '') + (cls ? '.' + cls : '') + '> L' + n.line);
    });
    const shown = out.slice(0, 90);
    return done(f.p + ' outline (depth<=' + maxD + '):\n' + shown.join('\n') + (out.length > shown.length ? '\n...(' + (out.length - shown.length) + ' more)' : '') + (skipped ? '\n(' + skipped + ' deeper elements hidden; raise depth)' : ''));
  }

  // ---------- bundler: inline local css/js into one document, keeping a line map ----------
  const CSP = "default-src 'none'; script-src 'unsafe-inline' 'unsafe-eval'; style-src 'unsafe-inline'; img-src data: blob:; media-src data: blob:; font-src data:; connect-src 'none'";
  function instrumentInline(chunk) {
    return chunk.replace(/(<script\b(?![^>]*\bsrc\s*=)[^>]*>)([\s\S]*?)(<\/script\s*>)/gi, (m, a, b, c) => a + instrumentLoops(b).code + c);
  }
  function bundleHtml(ws, entry, o) {
    o = o || {};
    const text = ws.files[entry], lineAt = mkLine(text), segs = [], inlined = [], missing = [];
    const push = (t, path, fileStart) => { if (t !== '') segs.push({ text: t, path, fileStart }); };
    const events = []; let m;
    const reTag = /<link\b[^>]*>|<script\b[^>]*\bsrc\s*=\s*["']([^"']+)["'][^>]*>\s*<\/script\s*>/gi;
    while ((m = reTag.exec(text))) {
      if (/^<link/i.test(m[0])) {
        const at = parseAttrs(m[0].replace(/^<link/i, '').replace(/\/?>$/, ''));
        if (/stylesheet/i.test(at.rel || '') && at.href && !isExternal(at.href)) events.push({ idx: m.index, end: m.index + m[0].length, kind: 'css', ref: at.href });
      } else if (!isExternal(m[1])) events.push({ idx: m.index, end: m.index + m[0].length, kind: 'js', ref: m[1], open: m[0].slice(0, m[0].indexOf('>') + 1) });
    }
    if (o.harness) {
      const hm = /<head\b[^>]*>/i.exec(text), dm = /^\s*<!doctype[^>]*>/i.exec(text);
      events.push({ idx: hm ? hm.index + hm[0].length : (dm ? dm[0].length : 0), end: hm ? hm.index + hm[0].length : (dm ? dm[0].length : 0), kind: 'inject' });
    }
    if (o.code) { const b = text.toLowerCase().lastIndexOf('</body'); const at = b >= 0 ? b : text.length; events.push({ idx: at, end: at, kind: 'extra' }); }
    events.sort((x, y) => x.idx - y.idx || (x.kind === 'inject' ? -1 : 1));
    let pos = 0;
    const chunk = (a, b) => { if (b > a) { const c = text.slice(a, b); push(o.instrument ? instrumentInline(c) : c, entry, lineAt(a)); } };
    events.forEach(ev => {
      if (ev.idx < pos) return;
      chunk(pos, ev.idx);
      if (ev.kind === 'inject') push('\n<meta http-equiv="Content-Security-Policy" content="' + CSP + '">\n<script>\n' + o.harness + '\n</script>\n', null, 0);
      else if (ev.kind === 'extra') { push('<script>\n', null, 0); push(o.instrument ? instrumentLoops(o.code).code : o.code, '(code)', 1); push('\n</script>\n', null, 0); }
      else {
        const target = resolveRef(entry, ev.ref), ln = lineAt(ev.idx);
        if (!Object.prototype.hasOwnProperty.call(ws.files, target)) { missing.push(ev.ref); chunk(ev.idx, ev.end); }
        else if (ev.kind === 'css') { inlined.push(target); push('<style>\n', entry, ln); push(ws.files[target], target, 1); push('\n</style>', entry, ln); }
        else {
          inlined.push(target);
          let js = ws.files[target].replace(/<\/script/gi, '<\\/script'); if (o.instrument) js = instrumentLoops(js).code;
          push(ev.open.replace(/\s+src\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/i, ''), entry, ln); push('\n', entry, ln); push(js, target, 1); push('\n</script>', entry, ln);
        }
      }
      pos = Math.max(pos, ev.end);
    });
    chunk(pos, text.length);
    let cur = 1; segs.forEach(s => { const nl = (s.text.match(/\n/g) || []).length; s.docStart = cur; s.docEnd = cur + nl; cur += nl; });
    return { html: segs.map(s => s.text).join(''), segs, inlined, missing };
  }
  function bundleEntry(ws, entry, o) {
    if (/\.html?$/i.test(entry)) return bundleHtml(ws, entry, o);
    const tmp = { files: { '__entry.html': '<!doctype html>\n<html><head></head><body>\n<script src="' + entry + '"></script>\n</body></html>' } };
    tmp.files[entry] = ws.files[entry];
    return bundleHtml(tmp, '__entry.html', o);
  }
  function mapDocLine(segs, L) {
    for (let i = 0; i < segs.length; i++) { const s = segs[i]; if (s.path && s.path !== '__entry.html' && L >= s.docStart && L <= s.docEnd) return { path: s.path, line: s.fileStart + (L - s.docStart) }; }
    return null;
  }

  // ---------- markdown -> html ----------
  function mdInline(s) {
    s = esc(s);
    return s.replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>').replace(/(^|[^*])\*([^*\s][^*]*)\*/g, '$1<em>$2</em>')
      .replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (m, t, u) => '<a href="' + (/^\s*javascript:/i.test(u) ? '#' : u) + '">' + t + '</a>');
  }
  function mdToHtml(md, title) {
    const L = String(md).replace(/\r/g, '').split('\n'), out = []; let i = 0;
    while (i < L.length) {
      const l = L[i]; let m;
      if (/^```/.test(l)) { const buf = []; i++; while (i < L.length && !/^```/.test(L[i])) buf.push(L[i++]); i++; out.push('<pre><code>' + esc(buf.join('\n')) + '</code></pre>'); continue; }
      if ((m = /^(#{1,6})\s+(.*)$/.exec(l))) { out.push('<h' + m[1].length + '>' + mdInline(m[2]) + '</h' + m[1].length + '>'); i++; continue; }
      if (/^\s*([-*_])\1{2,}\s*$/.test(l)) { out.push('<hr>'); i++; continue; }
      if (/^>\s?/.test(l)) { const buf = []; while (i < L.length && /^>\s?/.test(L[i])) buf.push(L[i++].replace(/^>\s?/, '')); out.push('<blockquote>' + mdInline(buf.join(' ')) + '</blockquote>'); continue; }
      if (/^\s*[-*+]\s+/.test(l)) { const buf = []; while (i < L.length && /^\s*[-*+]\s+/.test(L[i])) buf.push('<li>' + mdInline(L[i++].replace(/^\s*[-*+]\s+/, '')) + '</li>'); out.push('<ul>' + buf.join('') + '</ul>'); continue; }
      if (/^\s*\d+[.)]\s+/.test(l)) { const buf = []; while (i < L.length && /^\s*\d+[.)]\s+/.test(L[i])) buf.push('<li>' + mdInline(L[i++].replace(/^\s*\d+[.)]\s+/, '')) + '</li>'); out.push('<ol>' + buf.join('') + '</ol>'); continue; }
      if (!l.trim()) { i++; continue; }
      const buf = []; while (i < L.length && L[i].trim() && !/^(```|#{1,6}\s|>\s?|\s*[-*+]\s+|\s*\d+[.)]\s+)/.test(L[i])) buf.push(L[i++]);
      out.push('<p>' + mdInline(buf.join(' ')) + '</p>');
    }
    return '<!DOCTYPE html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n<title>' + esc(title || 'Document') + '</title>\n<style>body{font-family:system-ui,sans-serif;max-width:46rem;margin:1.5rem auto;padding:0 1rem;line-height:1.6}pre{background:#f4f4f4;padding:.8rem;overflow:auto;border-radius:6px}code{background:#f4f4f4;padding:0 .25em;border-radius:4px}blockquote{border-left:4px solid #ccc;margin-left:0;padding-left:1rem;color:#555}</style>\n</head>\n<body>\n' + out.join('\n') + '\n</body>\n</html>\n';
  }
  function toolToHtml(ws, a) {
    const f = needFile(ws, a.path); if (f.err) return f.err;
    let mode = String(a.mode || 'auto').toLowerCase();
    if (mode === 'auto') mode = /\.html?$/i.test(f.p) ? 'bundle' : (ext(f.p) === 'md' ? 'markdown' : 'text');
    const base = f.p.replace(/\.[^./]+$/, '');
    if (mode === 'bundle') {
      if (!/\.html?$/i.test(f.p)) return fail('bundle mode needs an .html file.');
      const b = bundleHtml(ws, f.p, {}), out = normPath(a.out) || (base + '.bundle.html');
      wsWrite(ws, out, b.html, 'to_html');
      return done('Created ' + out + ' (' + b.html.length + ' chars). Inlined: ' + (b.inlined.join(', ') || 'nothing') + '.' + (b.missing.length ? ' Not found in workspace (left as is): ' + b.missing.join(', ') + '.' : ''));
    }
    if (mode === 'markdown') { const out = normPath(a.out) || (base + '.html'); wsWrite(ws, out, mdToHtml(f.text, f.p), 'to_html'); return done('Created ' + out + ' from markdown.'); }
    if (mode === 'text') { const out = normPath(a.out) || (f.p + '.html'); wsWrite(ws, out, '<!DOCTYPE html>\n<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>' + esc(f.p) + '</title></head><body><pre>' + esc(f.text) + '</pre></body></html>\n', 'to_html'); return done('Created ' + out + ' (plain text page).'); }
    return fail('Unknown mode "' + a.mode + '". Use auto, bundle, markdown or text.');
  }
  function toolCheckJs(ws, a) {
    const f = needFile(ws, a.path); if (f.err) return f.err;
    if (/\.html?$/i.test(f.p)) return toolHtmlCheck(ws, a);
    if (!/^(js|mjs)$/.test(ext(f.p))) return fail('check_js supports .js files (and .html files, which are passed to html_check).');
    const errs = checkJsText(f.text);
    return errs.length ? done(f.p + ': ' + errs.length + ' problem(s):\n' + errs.join('\n'), { errors: errs.length }) : done(f.p + ': brackets balanced and syntax OK (' + splitLines(f.text).length + ' lines).', { errors: 0 });
  }

  // ---------- in-page harness (stringified into the sandboxed frame; must not use outer variables) ----------
  function harnessFn(CFG) {
    var T0 = performance.now(), logs = [], errors = [], frames = 0, ticks = 0, maxHeap = 0, lastYield = Date.now(), lgc = 0, dropped = 0;
    var origST = window.setTimeout, origSI = window.setInterval, raf = window.requestAnimationFrame;
    function post(o) { o.__ct = CFG.id; parent.postMessage(o, '*'); }
    function fmt(v) { try { if (typeof v === 'string') return v; if (v instanceof Error) return v.name + ': ' + v.message; if (typeof v === 'function') return '[function]'; var s = JSON.stringify(v); return s === undefined ? String(v) : s; } catch (e) { return String(v); } }
    function addLog(level, args) { if (logs.length < 60) logs.push({ level: level, text: Array.prototype.map.call(args, fmt).join(' ').slice(0, 300) }); else dropped++; }
    ['log', 'info', 'warn', 'error', 'debug'].forEach(function (k) { var o = console[k]; console[k] = function () { addLog(k, arguments); try { o.apply(console, arguments); } catch (e) {} }; });
    window.addEventListener('error', function (e) {
      if (e.target && e.target !== window && e.target.tagName) { errors.push({ message: 'Resource failed to load: <' + e.target.tagName.toLowerCase() + '> ' + (e.target.src || e.target.href || ''), line: 0 }); return; }
      errors.push({ message: String(e.message || e.error), line: (e.error && e.error.__ctLine) || e.lineno || 0 });
    }, true);
    window.addEventListener('unhandledrejection', function (e) { errors.push({ message: 'Unhandled promise rejection: ' + fmt(e.reason), line: 0 }); });
    try {
      var mk = function () { var st = {}; return { getItem: function (k) { return k in st ? st[k] : null; }, setItem: function (k, v) { st[k] = String(v); }, removeItem: function (k) { delete st[k]; }, clear: function () { st = {}; }, key: function (i) { return Object.keys(st)[i] || null; }, get length() { return Object.keys(st).length; } }; };
      Object.defineProperty(window, 'localStorage', { value: mk(), configurable: true });
      Object.defineProperty(window, 'sessionStorage', { value: mk(), configurable: true });
    } catch (e) {}
    window.__lgc = function (c) { window.__lg(); return c; };
    window.__lg = function () { if ((++lgc & 1023) === 0 && Date.now() - lastYield > CFG.loopMs) { lastYield = Date.now(); var er = new Error('Loop guard: a loop ran for over ' + CFG.loopMs + ' ms without yielding (possible infinite loop).'); try { var fr = String(er.stack).match(/srcdoc:(\d+)/g); if (fr && fr[1]) er.__ctLine = +fr[1].split(':')[1]; } catch (x) {} throw er; } };
    function wrapCb(fn) { if (typeof fn !== 'function') return fn; return function () { lastYield = Date.now(); ticks++; return fn.apply(this, arguments); }; }
    window.setTimeout = function (fn, ms) { return origST.apply(window, [wrapCb(fn), ms].concat(Array.prototype.slice.call(arguments, 2))); };
    window.setInterval = function (fn, ms) { return origSI.apply(window, [wrapCb(fn), ms].concat(Array.prototype.slice.call(arguments, 2))); };
    window.requestAnimationFrame = function (cb) { return raf.call(window, function (t) { frames++; lastYield = Date.now(); return cb(t); }); };
    if (performance.memory) origSI.call(window, function () { var h = performance.memory.usedJSHeapSize; if (h > maxHeap) maxHeap = h; }, 100);
    function report() {
      var dur = Math.max(1, performance.now() - T0), b = document.body, txt = b ? (typeof b.innerText === 'string' ? b.innerText : (b.textContent || '')) : '';
      if (performance.memory) maxHeap = Math.max(maxHeap, performance.memory.usedJSHeapSize);
      return { durationMs: Math.round(dur), frames: frames, fps: Math.round(frames * 10000 / dur) / 10, ticks: ticks, tps: Math.round(ticks * 10000 / dur) / 10,
        heapMB: maxHeap ? Math.round(maxHeap / 104857.6) / 10 : null, dom: document.getElementsByTagName('*').length, bodyChars: b ? b.innerHTML.length : 0,
        canvases: document.querySelectorAll('canvas').length, title: document.title, text: txt.replace(/\s+/g, ' ').trim().slice(0, 400), logs: logs, droppedLogs: dropped, errors: errors.slice(0, 20) };
    }
    var KC = { ArrowLeft: 37, ArrowUp: 38, ArrowRight: 39, ArrowDown: 40, Enter: 13, ' ': 32, Escape: 27, Tab: 9, Backspace: 8 };
    function q(sel) { var el = document.querySelector(sel); if (!el) throw new Error('No element matches "' + sel + '"'); return el; }
    function mouse(el, type, s) {
      var r = el.getBoundingClientRect(), init = { bubbles: true, cancelable: true, view: window, clientX: r.left + (s.x != null ? +s.x : r.width / 2), clientY: r.top + (s.y != null ? +s.y : r.height / 2) };
      try { el.dispatchEvent(new (type.indexOf('pointer') === 0 && window.PointerEvent ? PointerEvent : MouseEvent)(type, init)); } catch (e) {}
    }
    function key(type, k, target) {
      var ev = new KeyboardEvent(type, { key: k, code: k.length === 1 ? (/[a-z]/i.test(k) ? 'Key' + k.toUpperCase() : k === ' ' ? 'Space' : k) : k, bubbles: true, cancelable: true });
      var kc = KC[k] || (k.length === 1 ? k.toUpperCase().charCodeAt(0) : 0);
      try { Object.defineProperty(ev, 'keyCode', { get: function () { return kc; } }); Object.defineProperty(ev, 'which', { get: function () { return kc; } }); } catch (e) {}
      target.dispatchEvent(ev);
    }
    function observe() {
      var txt = function (e) { return (e.innerText || e.value || e.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim().slice(0, 40); };
      var btn = Array.prototype.slice.call(document.querySelectorAll('button,[role=button],a[href],input[type=button],input[type=submit]')).slice(0, 12).map(function (e) { return (e.id ? '#' + e.id + ' ' : '') + '"' + txt(e) + '"'; });
      var inp = Array.prototype.slice.call(document.querySelectorAll('input:not([type=button]):not([type=submit]),textarea,select')).slice(0, 8).map(function (e) { return (e.id ? '#' + e.id : e.name || e.tagName.toLowerCase()) + ' (' + (e.type || e.tagName.toLowerCase()) + ')=' + String(e.value).slice(0, 30); });
      var r = report(); return { title: r.title, text: r.text.slice(0, 300), buttons: btn, inputs: inp, canvases: r.canvases };
    }
    function doStep(s) {
      if (s.wait != null) return new Promise(function (res) { origST.call(window, function () { res({ value: 'waited ' + Math.min(5000, +s.wait || 0) + ' ms' }); }, Math.min(5000, +s.wait || 0)); });
      if (s.click) { var el = q(s.click); ['pointerdown', 'mousedown', 'pointerup', 'mouseup'].forEach(function (t) { mouse(el, t, s); }); if (s.x != null) mouse(el, 'click', s); else el.click(); return { value: 'clicked' }; }
      if (s.type) { var te = q(s.type); te.focus(); if ('value' in te) te.value = String(s.text == null ? '' : s.text); else te.textContent = String(s.text == null ? '' : s.text); te.dispatchEvent(new Event('input', { bubbles: true })); te.dispatchEvent(new Event('change', { bubbles: true })); return { value: 'typed' }; }
      if (s.key) { var tg = s.on ? q(s.on) : document.body, n = Math.max(1, Math.min(50, +s.times || 1)); for (var i = 0; i < n; i++) { key('keydown', String(s.key), tg); key('keyup', String(s.key), tg); } return { value: 'pressed ' + s.key + (n > 1 ? ' x' + n : '') }; }
      if (s.read) { var re = q(s.read), v = s.attr ? re.getAttribute(s.attr) : ((re.tagName === 'INPUT' || re.tagName === 'TEXTAREA' || re.tagName === 'SELECT') ? re.value : re.textContent); return { value: fmt(String(v == null ? '' : v).replace(/\s+/g, ' ').trim().slice(0, 200)) }; }
      if (s.exists) return { value: !!document.querySelector(s.exists) };
      if (s.count) return { value: document.querySelectorAll(s.count).length };
      if (s.eval) return { value: fmt(new Function('return (' + s.eval + ')')()).slice(0, 200) };
      if (s.assert) { var ok = !!new Function('return (' + s.assert + ')')(); return ok ? { value: 'assert passed' } : { assertFailed: true, error: 'assert failed: ' + s.assert }; }
      if (s.observe) return { value: observe() };
      throw new Error('Unknown step. Use one of: click, type(+text), key, read, exists, count, eval, assert, wait, observe.');
    }
    function runSteps(steps) {
      var out = [], i = 0;
      function next() {
        if (i >= steps.length) { post({ type: 'steps_done', results: out }); return; }
        var s = steps[i] || {}, idx = i++; lastYield = Date.now();
        Promise.resolve().then(function () { return doStep(s); }).then(function (r) { r = r || {}; out.push({ i: idx, ok: !r.assertFailed, value: r.value, error: r.error }); next(); },
          function (e) { out.push({ i: idx, ok: false, error: String(e && e.message || e) }); post({ type: 'steps_done', results: out }); });
      }
      next();
    }
    window.addEventListener('message', function (e) {
      var d = e.data; if (!d || d.__ctp !== CFG.id) return;
      if (d.type === 'steps') runSteps(d.steps || []); else if (d.type === 'report') post({ type: 'report', report: report() });
    });
    window.addEventListener('load', function () { origST.call(window, function () { post({ type: 'ready' }); }, 0); });
  }

  // ---------- run a page in a hidden sandboxed frame (browser only) ----------
  function runPage(ws, entry, o) {
    o = Object.assign({ timeoutMs: 2500, loopMs: 1500, steps: null, code: '', width: 360, height: 640 }, o || {});
    if (typeof document === 'undefined') return Promise.resolve({ ok: false, error: 'No browser DOM available in this environment.' });
    const id = 'ct' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    const harness = '(' + harnessFn.toString() + ')(' + JSON.stringify({ id, loopMs: o.loopMs }) + ');';
    let b; try { b = bundleEntry(ws, entry, { harness, instrument: true, code: o.code }); } catch (e) { return Promise.resolve({ ok: false, error: 'Bundling failed: ' + e.message }); }
    return new Promise(resolve => {
      const fr = document.createElement('iframe'); fr.setAttribute('sandbox', 'allow-scripts');
      fr.style.cssText = 'position:fixed;right:0;bottom:0;width:' + o.width + 'px;height:' + o.height + 'px;opacity:0;pointer-events:none;border:0;z-index:-1';
      let finished = false, stepsRes = null; const timers = [];
      const waitSum = (o.steps || []).reduce((a, s) => a + (s && s.wait ? Math.min(5000, +s.wait || 0) : 0), 0);
      const finish = r => { if (finished) return; finished = true; timers.forEach(clearTimeout); window.removeEventListener('message', onMsg); try { fr.remove(); } catch (e) {} resolve(Object.assign({ segs: b.segs, steps: stepsRes, inlined: b.inlined, missing: b.missing }, r)); };
      const later = (fn, ms) => timers.push(setTimeout(fn, ms));
      const send = m => { try { fr.contentWindow.postMessage(Object.assign({ __ctp: id }, m), '*'); } catch (e) {} };
      function onMsg(e) {
        const d = e.data; if (e.source !== fr.contentWindow || !d || d.__ct !== id) return;
        if (d.type === 'ready') { if (o.steps) later(() => send({ type: 'steps', steps: o.steps }), 150); else later(() => send({ type: 'report' }), o.timeoutMs); }
        else if (d.type === 'steps_done') { stepsRes = d.results; later(() => send({ type: 'report' }), 250); }
        else if (d.type === 'report') finish({ ok: true, report: d.report });
      }
      window.addEventListener('message', onMsg);
      later(() => finish({ ok: false, error: 'Timed out waiting for the page (possible infinite loop, or a very heavy page). Hidden frame removed.' }), 8000 + o.timeoutMs + waitSum + 3000);
      fr.srcdoc = b.html; document.body.appendChild(fr);
    });
  }
  const pad1 = n => (Math.round(n * 10) / 10).toString();
  function formatRun(ws, entry, r, steps, label) {
    if (!r.ok) return fail(r.error);
    const rep = r.report, L = [], paths = new Set();
    r.segs.forEach(s => { if (s.path && s.path !== '__entry.html' && s.path !== '(code)') paths.add(s.path); });
    const srcBytes = [...paths].reduce((a, p) => a + ((ws.files[p] || '').length), 0);
    L.push('Ran ' + label + ' for ' + pad1(rep.durationMs / 1000) + 's in a hidden sandboxed frame (no network, no real display).');
    L.push('Stats: ' + (rep.frames ? pad1(rep.fps) + ' frames/s (' + rep.frames + ' frames)' : 'no animation frames') + ' | timers: ' + pad1(rep.tps) + ' ticks/s (' + rep.ticks + ') | JS heap: ' + (rep.heapMB != null ? rep.heapMB + ' MB' : 'n/a') + ' | DOM: ' + rep.dom + ' elements, ' + rep.canvases + ' canvas | page HTML: ' + rep.bodyChars + ' chars | source: ' + paths.size + ' file(s), ' + srcBytes + ' chars');
    if (r.missing && r.missing.length) L.push('Warning: not found in workspace, not loaded: ' + r.missing.join(', '));
    const seen = {};
    rep.errors.forEach(e => { const m = e.line ? mapDocLine(r.segs, e.line) : null, key = (m ? m.path + ':' + m.line : '') + e.message; if (seen[key]) { seen[key].n++; return; } seen[key] = { e, m, n: 1 }; });
    const errs = Object.values(seen);
    if (errs.length) { L.push('ERRORS (' + rep.errors.length + '):'); errs.slice(0, 8).forEach(x => { const src = x.m && ws.files[x.m.path] ? splitLines(ws.files[x.m.path])[x.m.line - 1] : ''; L.push('- ' + (x.m ? (x.m.path === '__code.js' ? 'code' : x.m.path) + ':' + x.m.line + '  ' : '') + x.e.message + (x.n > 1 ? ' (x' + x.n + ')' : '') + (src ? '\n    ' + x.m.line + '| ' + src.trim().slice(0, 140) : '')); }); }
    else L.push('No errors.');
    if (rep.logs.length) { L.push('Console (' + rep.logs.length + (rep.droppedLogs ? '+' + rep.droppedLogs + ' dropped' : '') + '):'); rep.logs.slice(0, 12).forEach(x => L.push('- [' + x.level + '] ' + x.text)); }
    if (steps && r.steps) {
      L.push('Steps:'); let pass = 0, bad = 0;
      r.steps.forEach(s => { const d = JSON.stringify(steps[s.i] || {}).slice(0, 70); if (s.ok) pass++; else bad++; L.push((s.i + 1) + '. ' + d + ' -> ' + (s.ok ? (typeof s.value === 'object' ? JSON.stringify(s.value).slice(0, 300) : String(s.value)) : 'FAILED: ' + s.error)); });
      if (r.steps.length < steps.length) L.push('(stopped after a failing step; ' + (steps.length - r.steps.length) + ' step(s) not run)');
      L.push('Step result: ' + pass + ' ok, ' + bad + ' failed.');
    }
    L.push('Page title: "' + rep.title + '". Visible text: "' + rep.text.slice(0, 200) + '"');
    return done(L.join('\n'), { errors: errs.length, stats: { fps: rep.fps, tps: rep.tps, heapMB: rep.heapMB, dom: rep.dom } });
  }
  async function toolRunJs(ws, a) {
    const secs = Math.max(0.5, Math.min(10, +a.seconds || 2.5));
    let entry, wsr = ws, code = a.code ? String(a.code) : '';
    if (a.path) { const f = needFile(ws, a.path); if (f.err) return f.err; entry = f.p; }
    else if (code) { wsr = { files: { '__code.js': code } }; entry = '__code.js'; code = ''; }
    else return fail('Provide "path" (an .html or .js file) and/or "code".');
    if (!/\.(html?|js|mjs)$/i.test(entry)) return fail('run_js runs .html or .js files.');
    const r = await runPage(wsr, entry, { timeoutMs: secs * 1000, code });
    return formatRun(wsr, entry, r, null, entry === '__code.js' ? 'inline code' : entry);
  }
  async function toolUiTest(ws, a) {
    const f = needFile(ws, a.path); if (f.err) return f.err;
    const steps = a.steps; if (!Array.isArray(steps) || !steps.length) return fail('steps must be a non-empty array, e.g. [{"click":"#start"},{"wait":500},{"read":"#score"},{"key":"ArrowUp"},{"assert":"score > 0"}].');
    if (steps.length > 40) return fail('At most 40 steps per call.');
    const r = await runPage(ws, f.p, { timeoutMs: 500, steps });
    return formatRun(ws, f.p, r, steps, f.p + ' with ' + steps.length + ' step(s)');
  }

  // ---------- registry ----------
  const S = (desc, req) => ({ type: 'string', desc, req: !!req }), I = (desc, req) => ({ type: 'integer', desc, req: !!req }), B = desc => ({ type: 'boolean', desc });
  const TOOLS = {
    list_files: { title: 'فهرست فایل‌ها', desc: 'List all files in the workspace with line counts.', params: {}, run: ws => toolListFiles(ws) },
    read_file: { title: 'خواندن فایل', desc: 'Read a line range of a file (numbered). Max 150 lines per call.', params: { path: S('file path', true), from: I('first line (default 1)'), to: I('last line (default from+79)') }, run: toolReadFile },
    code_map: { title: 'نقشهٔ کد', desc: 'Outline of a .js/.html/.css/.md file: functions, classes, ids, listeners, loops with line numbers. Use this before reading.', params: { path: S('file path', true) }, run: toolCodeMap },
    search: { title: 'جستجو', desc: 'Find a word or code snippet in all files (or one file/folder). Returns file, line number and surrounding lines.', params: { query: S('text to find', true), path: S('limit to a file or folder'), regex: B('treat query as a regular expression'), word: B('whole word only'), case: B('case sensitive'), context: I('lines around each match, 0-5 (default 1)') }, run: toolSearch },
    edit_file: { title: 'ویرایش فایل', desc: 'Replace exact text in a file. Each edit needs a unique "find" string (copy it exactly from read_file). All edits succeed or none are applied. Reports JS/HTML problems after editing.', params: { path: S('file path', true), edits: { type: 'array', req: true, desc: 'list of {find, replace, all?}', items: { props: { find: { type: 'string' }, replace: { type: 'string' }, all: { type: 'boolean' } }, req: ['find', 'replace'] } } }, run: toolEditFile },
    write_file: { title: 'نوشتن فایل', desc: 'Create or fully overwrite a file. Prefer edit_file for small changes.', params: { path: S('file path', true), text: S('full file content', true) }, run: toolWriteFile },
    replace_lines: { title: 'جایگزینی خط‌ها', desc: 'Replace lines from..to of a file with new text (empty text deletes them). Use when edit_file cannot match exactly. Read the lines first.', params: { path: S('file path', true), from: I('first line', true), to: I('last line (default = from)'), text: S('replacement text') }, run: toolReplaceLines },
    rename_symbol: { title: 'تغییر نام نماد', desc: 'Rename a whole-word name (function, variable, id, class) in all .js/.html/.css files or one path. Strings and comments are included.', params: { old: S('current name', true), new: S('new name', true), path: S('limit to a file or folder') }, run: toolRenameSymbol },
    diff_last: { title: 'نمای تغییر آخر', desc: 'Show a line diff of the last change (all files of the last grouped change).', params: {}, run: ws => toolDiffLast(ws) },
    delete_file: { title: 'حذف فایل', desc: 'Delete a file (undo can restore it).', params: { path: S('file path', true) }, run: toolDeleteFile },
    undo: { title: 'برگرداندن', desc: 'Undo the last write/edit/delete.', params: {}, run: ws => toolUndo(ws) },
    check_js: { title: 'بررسی JS', desc: 'Check a .js file for unbalanced brackets (with line numbers) and syntax errors without running it.', params: { path: S('file path', true) }, run: toolCheckJs },
    html_check: { title: 'بررسی HTML', desc: 'Check HTML structure: unclosed/stray tags, duplicate ids, missing files, ids used in JS but absent, missing handlers.', params: { path: S('html file path', true) }, run: toolHtmlCheck },
    html_outline: { title: 'ساختار HTML', desc: 'Show the element tree of an HTML file (tags, ids, classes, line numbers).', params: { path: S('html file path', true), depth: I('max depth 1-8 (default 4)') }, run: toolHtmlOutline },
    to_html: { title: 'تبدیل به HTML', desc: 'Convert to HTML: "bundle" inlines local css/js into one html file; "markdown" converts .md to a page; "text" wraps text in a page.', params: { path: S('source file', true), mode: { type: 'string', enum: ['auto', 'bundle', 'markdown', 'text'], desc: 'conversion mode (default auto)' }, out: S('output path (optional)') }, run: toolToHtml },
    run_js: { title: 'اجرای بدون گرافیک', desc: 'Run an .html/.js file (or a code snippet) in a hidden sandboxed frame with no network. Returns errors with file:line, console output and stats (frames/s, timer ticks/s, JS heap, DOM size, source size). Runaway loops are stopped.', params: { path: S('html or js file'), code: S('extra JS to run after the page loads (or alone if no path)'), seconds: I('observe time 1-10 (default 2.5)') }, run: toolRunJs },
    ui_test: { title: 'تست مستقیم', desc: 'Operate your own page like a user and read the result. Steps: {"click":"#id"} {"type":"#input","text":"abc"} {"key":"ArrowUp","times":3} {"wait":300} {"read":"#score"} {"exists":".x"} {"count":"li"} {"eval":"expr"} {"assert":"expr"} {"observe":true}. Stops at the first failing step.', params: { path: S('html file', true), steps: { type: 'array', req: true, desc: 'list of step objects' } }, run: toolUiTest }
  };
  function usage(name) { const t = TOOLS[name]; return name + '(' + Object.keys(t.params).map(k => k + (t.params[k].req ? '' : '?') + ': ' + t.params[k].type).join(', ') + ')'; }
  function toolSpecText(names) { return (names || Object.keys(TOOLS)).map(n => '- ' + usage(n) + ': ' + TOOLS[n].desc).join('\n'); }
  function objSchema(items) { const props = {}; Object.keys(items.props).forEach(k => { props[k] = { type: items.props[k].type }; }); return { type: 'object', properties: props, required: items.req || [] }; }
  function paramSchema(p) { const s = { type: p.type }; if (p.enum) s.enum = p.enum; if (p.type === 'array') s.items = p.items ? objSchema(p.items) : { type: 'object' }; return s; }
  // JSON schema for one tool call: {"tool": "...", "args": {...}} (for llama.cpp --json-schema)
  function toolCallSchema(names) {
    return { anyOf: (names || Object.keys(TOOLS)).map(n => { const props = {}; Object.keys(TOOLS[n].params).forEach(k => { props[k] = paramSchema(TOOLS[n].params[k]); });
      return { type: 'object', properties: { tool: { const: n }, args: { type: 'object', properties: props, required: Object.keys(TOOLS[n].params).filter(k => TOOLS[n].params[k].req) } }, required: ['tool', 'args'] }; }) };
  }
  async function call(ws, name, args) {
    const t = TOOLS[name]; if (!t) return fail('Unknown tool "' + name + '". Available: ' + Object.keys(TOOLS).join(', '));
    args = args && typeof args === 'object' ? args : {}; const clean = {};
    for (const k of Object.keys(t.params)) {
      const p = t.params[k]; let v = args[k];
      if (v === undefined || v === null || v === '') { if (p.req) return fail('Missing required argument "' + k + '". Usage: ' + usage(name)); continue; }
      if (p.type === 'integer') { v = Number(v); if (!isFinite(v)) return fail('Argument "' + k + '" must be a number.'); }
      else if (p.type === 'boolean') v = v === true || v === 'true';
      else if (p.type === 'array' && typeof v === 'string') { try { v = JSON.parse(v); } catch (e) { return fail('Argument "' + k + '" must be a JSON array.'); } }
      if (p.type === 'array' && !Array.isArray(v)) return fail('Argument "' + k + '" must be an array.');
      if (p.type === 'string') v = String(v);
      if (p.enum && !p.enum.includes(v)) return fail('Argument "' + k + '" must be one of: ' + p.enum.join(', '));
      clean[k] = v;
    }
    try { const r = await t.run(ws, clean); r.tool = name; return r; } catch (e) { return fail('Tool "' + name + '" crashed: ' + (e && e.message || e), { tool: name }); }
  }

  // ---------- sample project (one deliberate bug: pressing "r" calls an undefined function) ----------
  function sampleProject() {
    return {
      'index.html': '<!DOCTYPE html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n<title>Clicker</title>\n<link rel="stylesheet" href="style.css">\n</head>\n<body>\n<h1>Clicker</h1>\n<p id="score">Score: 0</p>\n<button id="start">Start</button>\n<button id="bonus">+5</button>\n<script src="game.js"></script>\n</body>\n</html>\n',
      'style.css': 'body {\n  font-family: sans-serif;\n  text-align: center;\n}\n\n#score {\n  font-size: 2rem;\n}\n\nbutton {\n  padding: 0.6rem 1.2rem;\n}\n',
      'game.js': '// Tiny clicker game (sample with one deliberate bug)\nconst startBtn = document.getElementById(\'start\');\nconst bonusBtn = document.getElementById(\'bonus\');\nconst scoreEl = document.getElementById(\'score\');\nlet score = 0;\nlet running = false;\n\nfunction render() {\n  scoreEl.textContent = \'Score: \' + score;\n}\n\nfunction addPoint(n) {\n  score += n;\n  render();\n}\n\nfunction tick() {\n  if (!running) return;\n  addPoint(1);\n  setTimeout(tick, 100);\n}\n\nstartBtn.addEventListener(\'click\', () => {\n  running = true;\n  tick();\n});\n\nbonusBtn.addEventListener(\'click\', () => addPoint(5));\n\ndocument.addEventListener(\'keydown\', (e) => {\n  if (e.key === \' \') addPoint(5);\n  if (e.key === \'r\') reset();\n});\n\nrender();\n'
    };
  }

  return { LIM, newWs, normPath, wsToJSON, wsFromJSON, wsWrite, wsUndo, maskJs, bracketIssues, checkJsText, instrumentLoops, tokenizeHtml, buildTree, htmlCheck,
    bundleHtml, bundleEntry, mapDocLine, mdToHtml, diffText, TOOLS, call, usage, toolSpecText, toolCallSchema, sampleProject, runPage, formatRun, harnessFn, CSP };
})();
