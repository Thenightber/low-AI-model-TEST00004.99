// chat-controller.js — chat logic for the "Hearth" UI (loaded after ai-chat.js).
// The UI (index.html) owns: $, $$, h, fmt, ask, closeAll, openPanel and window.UI. Do not redeclare them here.
const SID = AIChat.sessionId();

// =============== State & storage (lab.js and studio.js read these globals) ===============
let chats = [];
try { chats = JSON.parse(localStorage.getItem('chats_v2') || '[]'); } catch (e) { chats = []; }
let curId = localStorage.getItem('cur');
let mode = localStorage.getItem('mode') || 'short';
let busy = false, status = 'unknown', lastInfo = null;

function save() {
  try { localStorage.setItem('chats_v2', JSON.stringify(chats)); localStorage.setItem('cur', curId); localStorage.setItem('mode', mode); } catch (e) {}
}
function cur() { return chats.find(c => c.id === curId); }
function makeChat() {
  const first = chats[0];
  if (first && first.msgs.length === 0) { curId = first.id; return first; }
  const c = { id: 'c' + Date.now(), title: 'گفتگوی جدید', t: Date.now(), msgs: [] };
  chats.unshift(c); curId = c.id; return c;
}
function usedThisSession() { return chats.some(c => c.msgs.some(m => m.sess === SID)); }

(function init() {
  const pend = localStorage.getItem('pendingNew');
  if (pend) localStorage.removeItem('pendingNew');
  if (pend || !cur()) makeChat();
  save();
})();

// =============== Status / memory ===============
function setStatus(s, d) { status = s; UI.setStatus(s, d); }
function pollInfo() {
  const i = AIChat.info(); if (!i) return;
  lastInfo = i; UI.setInfo(i);
}
setInterval(() => { if (!document.hidden) pollInfo(); }, 2500);

const renderChat = () => UI.chat.render(cur(), SID);

function chipText(st) {
  if (!st) return '';
  return 'first token ' + fmt(st.ttft) + 's · ' + st.tokens + ' tok · ' + fmt(st.tps) + ' tok/s · total ' + fmt(st.total) + 's' +
    (st.think != null ? ' · think ' + fmt(st.think) + 's' : '');
}

// =============== Sending ===============
function buildPrompt(t) {
  if (mode === 'short') return t + '\n\n[Reply in at most two short sentences.]';
  if (mode === 'think') return t + '\n\n[First write your brief step-by-step thinking inside <think></think> tags, then give the final answer after it.]';
  return t;
}

function send() {
  const text = UI.composer.value();
  if (!text || busy || status !== 'ready') return;
  const blocked = window.LAB && LAB.beforeSend();
  if (blocked) { ask(blocked, 'باشه', null); return; }
  const c = cur();
  UI.composer.clear();
  const um = { role: 'user', text, sess: SID };
  const m = { role: 'ai', raw: '', fa: '', st: null, sess: SID, mode, maxOut: window.LAB ? LAB.maxOut() : 0 };
  c.msgs.push(um, m);
  if (c.title === 'گفتگوی جدید') c.title = text.slice(0, 40);
  save();
  UI.chat.append(UI.chat.makeUser(um));
  const el = UI.chat.makeAi(); UI.chat.append(el); UI.chat.toBottom();

  busy = true; UI.setBusy(true);
  const t0 = performance.now(); let tFirst = 0, tThink = 0, tEnd = 0, n = 0, raf = 0, lastLive = 0;
  const r = el._r;
  r.wait.textContent = 'مدل پیام را می‌خواند… 0.0s';
  UI.chat.paintAi(el, m, true);
  const timer = setInterval(() => {
    if (!tFirst) r.wait.textContent = 'مدل پیام را می‌خواند… ' + fmt((performance.now() - t0) / 1000) + 's';
  }, 200);

  const repaint = () => { raf = 0; const nb = UI.chat.nearBottom(); UI.chat.paintAi(el, m, true); if (nb) UI.chat.toBottom(); };
  const finish = () => {
    clearInterval(timer); busy = false; UI.setBusy(false);
    UI.chat.paintAi(el, m, false); save(); pollInfo(); UI.chat.toBottom();
  };

  AIChat.send(buildPrompt(text),
    en => {
      tEnd = performance.now(); m.raw = en;
      const gen = Math.max((tEnd - (tFirst || t0)) / 1000, 0.001);
      m.st = { ttft: ((tFirst || tEnd) - t0) / 1000, tokens: n, tps: n / gen, total: (tEnd - t0) / 1000,
               think: tThink && tFirst ? (tThink - tFirst) / 1000 : null };
    },
    fa => { m.fa = fa; finish(); },
    tok => {
      const now = performance.now();
      if (!tFirst) tFirst = now;
      n++; m.raw += tok;
      if (!tThink && m.raw.indexOf('</think>') >= 0) tThink = now;
      if (now - lastLive > 300) { lastLive = now; UI.setLive(n / Math.max((now - tFirst) / 1000, 0.2)); }
      if (!raf) raf = requestAnimationFrame(repaint);
    },
    err => { m.err = err; finish(); },
    { maxTokens: window.LAB ? LAB.maxOut() : 0 });
  if (window.LAB) LAB.lastPrompt = buildPrompt(text);
}

// =============== Drawer: chats ===============
function renderDrawer() {
  UI.drawer.render(chats, curId,
    id => { if (busy) return; curId = id; save(); closeAll(); renderChat(); },
    id => ask('این گفتگو حذف شود؟', 'حذف', () => {
      chats = chats.filter(k => k.id !== id);
      if (!chats.length || !cur()) makeChat();
      save(); renderDrawer(); renderChat();
    }));
}

// =============== Settings ===============
const MODES = [
  ['short', 'کوتاه و سریع', 'حداکثر دو جمله — برای تست سرعت'],
  ['normal', 'عادی', 'مدل آزادانه جواب می‌دهد (طولانی‌تر و کندتر)'],
  ['think', 'تفکر مرحله‌ای (آزمایشی)', 'مدل اول فکرش را می‌نویسد، بعد جواب می‌دهد']
];
function renderModes() { UI.settings.renderModes(MODES, mode, k => { mode = k; save(); renderModes(); }); }

// =============== Report (writes into #rep-body; the UI skins kv/chart/textarea.rep) ===============
function kv(k, v) { const r = h('div', 'kv'), b = h('b', null, v); b.dir = 'auto'; r.append(h('span', null, k), b); return r; }
function chart(title, rows, max, cls, unit) {
  const w = h('div'); w.appendChild(h('h4', null, title));
  rows.forEach((v, i) => {
    const r = h('div', 'cr'); const bar = h('div', 'bar ' + (cls || '')); const fill = document.createElement('i');
    fill.style.width = Math.max(2, v / max * 100) + '%'; bar.appendChild(fill);
    r.append(h('u', null, '#' + (i + 1)), bar, h('em', null, fmt(v) + unit)); w.appendChild(r);
  });
  return w;
}
function openReport(silent) {   // silent = fill the report without switching tabs
  pollInfo();
  const body = $('#rep-body'); body.textContent = '';
  const all = chats.flatMap(c => c.msgs).filter(m => m.role === 'ai' && m.st && m.st.tokens > 0);
  const avg = f => all.length ? all.reduce((a, m) => a + f(m.st), 0) / all.length : 0;
  const i = lastInfo;
  UI.report.setSummary({ tps: avg(s => s.tps), ttft: avg(s => s.ttft), n: all.length, ramFreeGb: i ? i.ramAvailMb / 1024 : null });

  body.appendChild(h('h4', null, 'دستگاه و مدل'));
  if (i) {
    [['دستگاه', i.device], ['اندروید (SDK)', String(i.sdk)], ['هسته‌های CPU', String(i.cores)],
     ['رم کل / آزاد', fmt(i.ramTotalMb / 1024) + ' / ' + fmt(i.ramAvailMb / 1024) + ' GB'],
     ['رم مصرفی برنامه', fmt(i.appPssMb / 1024, 2) + ' GB'], ['حجم فایل مدل', i.modelMb + ' MB']]
      .forEach(([k, v]) => body.appendChild(kv(k, v)));
  } else body.appendChild(kv('وضعیت', 'اطلاعات دستگاه فقط داخل APK هست'));

  body.appendChild(h('h4', null, 'عملکرد (همه‌ی پاسخ‌ها)'));
  if (!all.length) body.appendChild(kv('پاسخ ثبت‌شده', '0'));
  else {
    [['تعداد پاسخ', String(all.length)], ['میانگین سرعت', fmt(avg(s => s.tps)) + ' tok/s'],
     ['میانگین تا اولین توکن', fmt(avg(s => s.ttft)) + ' s'], ['میانگین زمان کل', fmt(avg(s => s.total)) + ' s'],
     ['مجموع توکن‌ها', String(all.reduce((a, m) => a + m.st.tokens, 0))]]
      .forEach(([k, v]) => body.appendChild(kv(k, v)));
    const last = all.slice(-15);
    body.appendChild(chart('سرعت تولید هر پاسخ (tok/s)', last.map(m => m.st.tps), Math.max(...last.map(m => m.st.tps), 1), '', ''));
    body.appendChild(chart('زمان تا اولین توکن (ثانیه)', last.map(m => m.st.ttft), Math.max(...last.map(m => m.st.ttft), 1), 'alt', 's'));
  }

  const lines = ['Offline AI Test report'];
  if (i) lines.push(i.device + ' | SDK ' + i.sdk + ' | cores ' + i.cores,
    'RAM total ' + i.ramTotalMb + ' MB, avail ' + i.ramAvailMb + ' MB, app ' + i.appPssMb + ' MB | model ' + i.modelMb + ' MB');
  lines.push('responses ' + all.length + ' | avg ' + fmt(avg(s => s.tps)) + ' tok/s | avg first token ' + fmt(avg(s => s.ttft)) + 's | avg total ' + fmt(avg(s => s.total)) + 's');
  all.slice(-10).forEach((m, k) => lines.push('#' + (k + 1) + ' [' + (m.mode || '?') + '] ' + chipText(m.st)));
  body.appendChild(h('h4', null, 'گزارش متنی (برای کپی و ارسال به من)'));
  const ta = h('textarea', 'rep'); ta.readOnly = true; ta.value = lines.join('\n'); body.appendChild(ta);
  ta.onclick = () => ta.select();
  if (!silent) openPanel('#sheet-rep');
}

// =============== Bindings ===============
$('#go').onclick = send;
$('#inp').addEventListener('keydown', e => { if (e.key === 'Enter' && e.ctrlKey) send(); });
$('#pick').onclick = () => AIChat.pickModel();
$('#bmenu').addEventListener('click', renderDrawer);
$('#bset').addEventListener('click', renderModes);
$('#bnew').onclick = () => {
  if (busy) return;
  if (usedThisSession()) {
    closeAll();
    ask('برای شروع گفتگوی جدید باید حافظه‌ی مدل پاک شود. برنامه دوباره باز می‌شود و مدل از نو لود می‌شود (ممکن است کمی طول بکشد). ادامه؟', 'ادامه', () => {
      localStorage.setItem('pendingNew', '1'); save(); AIChat.restart();
    });
  } else { makeChat(); save(); closeAll(); renderChat(); }
};
$('#delall').onclick = () => ask('همه‌ی گفتگوها پاک شوند؟', 'پاک کن', () => { chats = []; makeChat(); save(); closeAll(); renderChat(); });
$('#brep').onclick = () => openReport(false);
$('#blab').addEventListener('click', () => openReport(true));   // entering the lab room shows a filled report (its default tab)
$('#blabtools').addEventListener('click', () => $('#blab').click());   // makes lab.js render when the "tools" tab is tapped

// =============== Start ===============
AIChat.onStatus = setStatus;
setStatus(AIChat.status());
(function () { const inf = AIChat.info(); if (inf && inf.loadError && AIChat.status() === 'need_model') setStatus('need_model', inf.loadError); })();
renderChat(); renderModes(); pollInfo();
