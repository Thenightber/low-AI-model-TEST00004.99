package com.example.computerhunt

import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * Runtime for the image studio. Every AI model runs as its own native process
 * (llama-cli, llama-mtmd-cli, sd-cli). When the process exits, its RAM is fully freed ("model off").
 * JavaScript sees this object as window.Tools.
 *
 * Events to JS:  window.onToolEvent({job, type: out|err|exit|timeout, text, code, ms})
 *                window.onLibEvent({type: progress|file_done|error|done|verify|verify_error, modelId, file, bytes, msg})
 *                (verify: msg = SHA-256 hex of the library file; verify_error: msg = reason)
 */
class ToolBridge(
    private val activity: AppCompatActivity,
    private val webView: WebView,
    private val launchPicker: () -> Unit
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val libRoot = File(activity.filesDir, "library").apply { mkdirs() }
    private val studioRoot = File(activity.cacheDir, "studio").apply { mkdirs() }
    private val procs = ConcurrentHashMap<String, Process>()
    @Volatile private var pendingModelId = ""

    // The binaries are packaged as lib*.so so Android extracts them to nativeLibraryDir with execute permission.
    private val toolFiles = mapOf(
        "llama-cli" to "libllama_cli.so",
        "llama-completion" to "libllama_completion.so",
        "llama" to "libllama_unified.so",
        "llama-mtmd-cli" to "libllama_mtmd_cli.so",
        "sd-cli" to "libsd_cli.so"
    )

    private fun nativeDir(): String = activity.applicationInfo.nativeLibraryDir
    private fun safeName(s: String) = s.replace(Regex("[^A-Za-z0-9._-]"), "_")

    fun destroy() {
        procs.values.forEach { try { it.destroyForcibly() } catch (_: Throwable) {} }
        scope.cancel()
    }

    // ---------- info ----------

    @JavascriptInterface
    fun runtime(): String {
        val tools = JSONObject()
        for ((name, file) in toolFiles) {
            val f = File(nativeDir(), file)
            tools.put(name, JSONObject().put("exists", f.exists()).put("bytes", if (f.exists()) f.length() else 0))
        }
        return JSONObject()
            .put("nativeDir", nativeDir())
            .put("libRoot", libRoot.absolutePath)
            .put("studioRoot", studioRoot.absolutePath)
            .put("abi", Build.SUPPORTED_ABIS.firstOrNull() ?: "")
            .put("tools", tools)
            .put("freeBytes", try { libRoot.usableSpace } catch (_: Throwable) { 0L })
            .toString()
    }

    // ---------- model library ----------

    @JavascriptInterface
    fun lib(): String {
        val arr = JSONArray()
        libRoot.listFiles()?.filter { it.isDirectory }?.forEach { d ->
            val files = JSONArray()
            d.listFiles()?.filter { it.isFile && !it.name.endsWith(".part") }?.forEach {
                files.put(JSONObject().put("name", it.name).put("bytes", it.length()))
            }
            arr.put(JSONObject().put("id", d.name).put("files", files))
        }
        return arr.toString()
    }

    @JavascriptInterface
    fun libImport(modelId: String) {
        pendingModelId = safeName(modelId)
        activity.runOnUiThread { launchPicker() }
    }

    @JavascriptInterface
    fun libDelete(modelId: String) {
        try { File(libRoot, safeName(modelId)).deleteRecursively() } catch (_: Throwable) {}
    }

    // SHA-256 of one file in the model library (result via window.onLibEvent type "verify")
    @JavascriptInterface
    fun libVerify(modelId: String, fileName: String) {
        val f = File(File(libRoot, safeName(modelId)), safeName(fileName))
        if (!f.isFile) { sendLib("verify_error", modelId, fileName, 0, "file not found"); return }
        scope.launch {
            try {
                val md = MessageDigest.getInstance("SHA-256")
                val buf = ByteArray(1 shl 20)
                var total = 0L
                f.inputStream().use { ins ->
                    while (true) {
                        val n = ins.read(buf)
                        if (n <= 0) break
                        md.update(buf, 0, n)
                        total += n
                    }
                }
                sendLib("verify", modelId, fileName, total, md.digest().joinToString("") { "%02x".format(it) })
            } catch (t: Throwable) {
                sendLib("verify_error", modelId, fileName, 0, t.message ?: t::class.java.simpleName)
            }
        }
    }

    fun importFiles(uris: List<Uri>) {
        val id = pendingModelId
        if (id.isEmpty() || uris.isEmpty()) return
        scope.launch {
            val dir = File(libRoot, id).apply { mkdirs() }
            for (uri in uris) {
                val name = safeName(displayName(uri) ?: "file_${System.currentTimeMillis()}")
                try {
                    val tmp = File(dir, "$name.part")
                    var total = 0L
                    var next = 64L * 1048576
                    activity.contentResolver.openInputStream(uri)?.use { ins ->
                        tmp.outputStream().use { out ->
                            val buf = ByteArray(1 shl 20)
                            while (true) {
                                val n = ins.read(buf)
                                if (n <= 0) break
                                out.write(buf, 0, n)
                                total += n
                                if (total >= next) { next += 64L * 1048576; sendLib("progress", id, name, total, "") }
                            }
                        }
                    } ?: throw IOException("cannot open file")
                    val dest = File(dir, name)
                    if (dest.exists()) dest.delete()
                    tmp.renameTo(dest)
                    sendLib("file_done", id, name, total, "")
                } catch (t: Throwable) {
                    File(dir, "$name.part").delete()
                    sendLib("error", id, name, 0, t.message ?: t::class.java.simpleName)
                }
            }
            sendLib("done", id, "", 0, "")
        }
    }

    private fun displayName(uri: Uri): String? = try {
        activity.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    } catch (_: Throwable) { null }

    // ---------- running tools ----------

    @JavascriptInterface
    fun newRunDir(runId: String): String {
        val d = File(studioRoot, safeName(runId)).apply { mkdirs() }
        return d.absolutePath
    }

    @JavascriptInterface
    fun run(jobId: String, tool: String, argsJson: String, timeoutSec: Int) {
        val fileName = toolFiles[tool]
        if (fileName == null) { sendTool(jobId, "exit", "unknown tool: $tool", -1, 0); return }
        val exe = File(nativeDir(), fileName)
        if (!exe.exists()) { sendTool(jobId, "exit", "tool binary missing: $fileName", -2, 0); return }
        val args: List<String> = try {
            val a = JSONArray(argsJson); List(a.length()) { a.getString(it) }
        } catch (t: Throwable) { sendTool(jobId, "exit", "bad args: ${t.message}", -1, 0); return }

        scope.launch {
            val t0 = System.currentTimeMillis()
            try {
                val pb = ProcessBuilder(listOf(exe.absolutePath) + args).directory(studioRoot)
                pb.environment()["LD_LIBRARY_PATH"] = nativeDir()
                val p = pb.start()
                procs[jobId] = p
                try { p.outputStream.close() } catch (_: Throwable) {}   // no stdin: never wait for interactive input
                val tOut = Thread { pump(jobId, "out", p.inputStream) }.also { it.start() }
                val tErr = Thread { pump(jobId, "err", p.errorStream) }.also { it.start() }
                val finished = if (timeoutSec > 0) p.waitFor(timeoutSec.toLong(), TimeUnit.SECONDS) else { p.waitFor(); true }
                if (!finished) p.destroyForcibly()
                tOut.join(2000); tErr.join(2000)
                procs.remove(jobId)
                val code = if (finished) p.exitValue() else -3
                sendTool(jobId, if (finished) "exit" else "timeout", "", code, System.currentTimeMillis() - t0)
            } catch (t: Throwable) {
                procs.remove(jobId)
                sendTool(jobId, "exit", "failed to start: ${t.message}", -4, System.currentTimeMillis() - t0)
            }
        }
    }

    @JavascriptInterface
    fun cancel(jobId: String) {
        try { procs[jobId]?.destroyForcibly() } catch (_: Throwable) {}
    }

    private fun pump(jobId: String, kind: String, ins: InputStream) {
        val reader = InputStreamReader(ins, Charsets.UTF_8)
        val buf = CharArray(2048)
        try {
            while (true) {
                val n = reader.read(buf)
                if (n <= 0) break
                sendTool(jobId, kind, String(buf, 0, n), 0, 0)
            }
        } catch (_: Throwable) {}
    }

    @JavascriptInterface
    fun studioInfo(): String {
        var bytes = 0L
        var files = 0
        studioRoot.walkTopDown().filter { it.isFile }.forEach { bytes += it.length(); files++ }
        return JSONObject().put("bytes", bytes).put("files", files).toString()
    }

    @JavascriptInterface
    fun clearStudio() {
        try { studioRoot.listFiles()?.forEach { it.deleteRecursively() } } catch (_: Throwable) {}
    }

    // ---------- images ----------

    private fun inStudio(path: String): File? = try {
        val f = File(path).canonicalFile
        if (f.path.startsWith(studioRoot.canonicalPath + File.separator)) f else null
    } catch (_: Throwable) { null }

    @JavascriptInterface
    fun readImage(path: String): String {
        val f = inStudio(path) ?: return "error:outside studio folder"
        if (!f.exists() || f.length() == 0L) return "error:missing"
        return try { "data:image/png;base64," + Base64.encodeToString(f.readBytes(), Base64.NO_WRAP) }
        catch (t: Throwable) { "error:" + (t.message ?: "read failed") }
    }

    @JavascriptInterface
    fun saveImage(path: String, name: String): String {
        val f = inStudio(path) ?: return "error:outside studio folder"
        if (!f.exists()) return "error:missing"
        return try {
            val safe = safeName(name)
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, safe)
                put(MediaStore.Downloads.MIME_TYPE, "image/png")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val resolver = activity.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return "error:could not create file"
            resolver.openOutputStream(uri)?.use { it.write(f.readBytes()) }
            "ok:$safe"
        } catch (t: Throwable) { "error:" + (t.message ?: t::class.java.simpleName) }
    }

    @JavascriptInterface
    fun openUrl(url: String) {
        if (!url.startsWith("https://") && !url.startsWith("http://")) return
        activity.runOnUiThread {
            try { activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Throwable) {}
        }
    }

    // ---------- events ----------

    private fun safe(j: JSONObject): String = j.toString().replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")

    private fun sendTool(job: String, type: String, text: String, code: Int, ms: Long) {
        val j = JSONObject().put("job", job).put("type", type).put("text", text).put("code", code).put("ms", ms)
        webView.post { webView.evaluateJavascript("window.onToolEvent&&window.onToolEvent(${safe(j)})", null) }
    }

    private fun sendLib(type: String, modelId: String, file: String, bytes: Long, msg: String) {
        val j = JSONObject().put("type", type).put("modelId", modelId).put("file", file).put("bytes", bytes).put("msg", msg)
        webView.post { webView.evaluateJavascript("window.onLibEvent&&window.onLibEvent(${safe(j)})", null) }
    }
}
