package com.example.computerhunt

import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * The only door from the app to the internet (window.SearchBridge).
 *  - OFF by default; the user turns it on explicitly (stored in a flag file).
 *  - https only, and only the three search-service hosts below.
 *  - no redirects, response size capped.
 * The page search-tool.html calls request(...) and receives window.onHttpResult(id, status, text, err).
 */
class SearchBridge(private val activity: AppCompatActivity, private val webView: WebView) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val flag = File(activity.filesDir, "net_enabled")
    private val allowedHosts = setOf("api.tavily.com", "api.search.brave.com", "google.serper.dev")
    private val maxBytes = 2 * 1024 * 1024

    fun destroy() = scope.cancel()

    @JavascriptInterface
    fun enabled(): Boolean = flag.exists()

    @JavascriptInterface
    fun setEnabled(on: Boolean) {
        try { if (on) flag.writeText("1") else flag.delete() } catch (_: Throwable) {}
    }

    @JavascriptInterface
    fun hosts(): String = allowedHosts.joinToString(", ")

    @JavascriptInterface
    fun request(id: String, method: String, url: String, headersJson: String, body: String, timeoutSec: Int) {
        if (!enabled()) { reply(id, 0, "", "اینترنت برای جستجو در برنامه خاموش است (تب «وب» را ببین)."); return }
        val u = try { URL(url) } catch (_: Throwable) { reply(id, 0, "", "آدرس نامعتبر"); return }
        if (u.protocol != "https" || u.host !in allowedHosts) { reply(id, 0, "", "این آدرس مجاز نیست: ${u.host}"); return }
        val m = method.uppercase()
        if (m != "GET" && m != "POST") { reply(id, 0, "", "متد مجاز نیست"); return }

        scope.launch {
            var conn: HttpURLConnection? = null
            try {
                conn = (u.openConnection() as HttpURLConnection).apply {
                    requestMethod = m
                    instanceFollowRedirects = false
                    val ms = (timeoutSec.coerceIn(3, 90)) * 1000
                    connectTimeout = ms; readTimeout = ms
                    val h = JSONObject(if (headersJson.isBlank()) "{}" else headersJson)
                    h.keys().forEach { k ->
                        if (!k.equals("host", true) && !k.equals("content-length", true)) setRequestProperty(k, h.getString(k))
                    }
                    if (m == "POST" && body.isNotEmpty()) {
                        doOutput = true
                        outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    }
                }
                val status = conn.responseCode
                val stream = if (status >= 400) conn.errorStream else conn.inputStream
                val out = ByteArrayOutputStream()
                stream?.use { ins ->
                    val buf = ByteArray(8192)
                    while (out.size() < maxBytes) {
                        val n = ins.read(buf)
                        if (n <= 0) break
                        out.write(buf, 0, n)
                    }
                }
                reply(id, status, out.toString("UTF-8"), "")
            } catch (t: Throwable) {
                reply(id, 0, "", t.message ?: t::class.java.simpleName)
            } finally {
                conn?.disconnect()
            }
        }
    }

    private fun q(s: String) = JSONObject.quote(s).replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")

    // Delivered to the main frame; studio.js forwards it to the search page's iframe.
    private fun reply(id: String, status: Int, text: String, err: String) {
        val js = "window.onHttpResult&&window.onHttpResult(${q(id)},$status,${q(text)},${if (err.isEmpty()) "null" else q(err)})"
        webView.post { webView.evaluateJavascript(js, null) }
    }
}
