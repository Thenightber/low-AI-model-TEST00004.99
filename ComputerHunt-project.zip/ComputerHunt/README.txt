Build: GitHub Actions (see build.yml) or Android Studio (needs JDK 17).
Model: download qwen2.5-1.5b-instruct-q4_k_m.gguf (~1.1 GB) to the phone's Downloads folder.
First launch: tap "Choose model file" and select it. It is copied into the app once.
Your real game: replace app/src/main/assets/index.html and paste assets/ai-chat.js into it.
